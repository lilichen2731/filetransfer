# Introduction 
## VDSM (Vegetation Density Scenario Modelling)
Reference for concept developing: [Li et al. (2021)](https://www.mdpi.com/2072-4292/13/6/1147). Li et al. (2021) used spatially fused historic satellite and climate data to predict NDVI (normalised difference vegetation index) in growth seasons.

We adapt the concept from Li et al. (2021) and train Machine Learning (ML) regresssion models to forecast the EVI (enhanced vegetation index) for future 3, 6, 12 months for a given starting month. The client's problem is to actively know where and when (green and non-green) vegetation becomes too dense and too close to the rail network. [EVI](https://www.soft.farm/en/blog/vegetation-indices-ndvi-evi-gndvi-cvi-true-color-140) is used as a vegetation proxy because we want to capture the signal from both the green and lesser green vegetations. 
NDVI is biased towards the signal from green vegetation and could lead to missing detection of other vegetations, as well as the saturation in high-density vegetation areas.
Other advantages of EVI over NDVI is that  EVI uses  blue reflection region to correct background soil signals and reduce atmospheric effects, including aerosol scattering. 

The [vegetation phenology notebook](https://docs.dea.ga.gov.au/notebooks/Real_world_examples/Vegetation_phenology.html) from Digital Earth Australia (DEA) contains starter information about how to derive EVI from satellite data. 
We use the methodology from DEA as best practices for learning about vegetation science from satellite data.

## Data Sources:
We use 4 main analysis-ready datasets, all publicly available. Customised codes are developed to retrieve those data to our client's cloud environment.
1. [DEA Sentinel-2 dataset](https://explorer-aws.dea.ga.gov.au/products) product=`'s2a_ard_granule', 's2b_ard_granule'` in `collection 2`. Pixel scale 10m (spatial resolution 10-20m, band dependent). Used for deriving spatially resolved EVI from the RED, NIR, and Blue bands. 
2. [DEA Fractional Cover dataset](https://data.dea.ga.gov.au/?prefix=fractional-cover/) *product=`fc_percentile_albers_annual`. Resolution 25m.  Used for classifying land covers into 3 vegetation types: annual green
 (pixels dominated by photosynthesis all year around), non-green (pixels dominated by photosynthesis for a certain period of the time), 
 bare soil (pixels having no photosynthesis most of the time). <br>
*Note that the factional cover dataset will be [depreciated on Feb 14, 2022](https://cmi.ga.gov.au/data-products/dea/119/dea-fractional-cover-landsat-deprecated). This won't impact the current production models. For future upgrade/retraining of models, we recommend using an [upgraded fractional cover dataset](https://www.dea.ga.gov.au/news/landsat-collection-upgrade).
Grouping pixels of similar land cover/vegetation types helps improve the EVI forecasting model's accuracy, because different pixel types have different growth patterns and worth a model of their own. There is plenty of room to improve the model using updated land cover classification types. Our use of pre-2022 fractional coverage dataset is only a start.
3. [Copernicus ERA5-Land monthly averaged data](https://cds.climate.copernicus.eu/cdsapp#!/dataset/reanalysis-era5-land-monthly-means?tab=overview). Resolution 9km. Used for obtaining climate features such as sunlight, rainfall, soil moisture, wind speed etc. 
4. [NOAA global CO2 monthly trend](https://gml.noaa.gov/webdata/ccgg/trends/co2/co2_mm_gl.txt). Not spatially resolved. Used for tracing the effect of [CO2 cycle and global warming](https://earthobservatory.nasa.gov/features/CarbonCycle) on vegetation growth.

## Function App:
The function app ingests data from the 3 sources - DEA, Copernicus, NOAA, and then triggers the merge pipeline by sending a request to the pipeline REST endpoint. <br>
It uses the Durable Functions extension and follows the [Fan out/fan in pattern](https://docs.microsoft.com/en-us/azure/azure-functions/durable/durable-functions-overview?tabs=python#fan-in-out) <br>
Code for the function app is available under `functionapp/ParallelQuery`. Due to the size of the rail network, we are unable to query the Sentinel-2 data for the entire network at once.
Therefore, we have split the network into 249 5km regions. `grouped_chainage_df_5km_v2.csv` contains the latitude and longitude bounding boxes for each 5km region.
The function app consists of 6 functions:
- `DurableFunctionsHttpStart`: Triggers the orchestrator when an HTTP request is received.
- `DurableFunctionsOrchestrator`: Orchestrates the execution of the following 4 functions. 
The orchestrator passes the latitude and longitude bounding boxes of each 5km region to the DataQuery function in parallel, along with the month parameter.
It also passes the month parameter to the `CO2Query` and `ClimateQuery` functions. After completion of these 3 functions, the orchestrator triggers the `PipelineTrigger` function which triggers the AML pipeline for merging Sentinel-2 data.
- `DataQuery`: Searches the DEA STAC catalogue for Sentinel-2 data matching the given bounding box and month. This data is returned as an xarray.Dataset. 
`pickle.dumps()` is used to serialise the dataset, which is then uploaded to the storage account as a pkl file under `year/month/staging/region_name.pkl`. The orchestrator function calling the DataQuery results in one Sentinel-2 pkl file per region per month.
- `CO2Query`: Reads the txt file from [this location](https://gml.noaa.gov/webdata/ccgg/trends/co2/co2_mm_gl.txt) and writes it to the storage account under `co2/month.txt`.
- `ClimateQuery`: Queries the [CDS API](https://cds.climate.copernicus.eu/api/v2) for ERA5-Land monthly averaged data from 2015 to the current month. The data is returned as an xarray.Dataset which is uploaded to climate/month.pkl.
- `PipelineTrigger`: Sends a POST request to the AML merge pipeline REST endpoint to trigger the merging of Sentinel-2 data.

## Data Merge and Fusion:
The 4 types of data are merged and fused spatiotemporaly. 

The merge step occurs in an AML pipeline, which then triggers the fusion AML pipeline. The fusion pipeline reads the climate, CO2, and merged Sentinel-2 data from the storage account. 
The climate and CO2 data are reprojected using bilinear interpolation to match the 10m resolution of the Sentinel-2 data. Once complete, this fused data is written as a csv file to the storage account, ready for inference. The fusion step is performed separately for the bare soil, green, and non-green vegetation, and each vegetation type is written into a separate folder.
The final fused data has a common spatial pixel grid of 10m, based on Sentinel-2. 

Data fusion pipelines are separated into training fusion and inference fusion, to generate data for training and monthly inference respectively. 
- Training fusion: The monthly data from `2015-11 `to `2021-07` are used for current version (Feb. 2022) of training. 3 targets of 3, 6, 12 months are prepared as 'ground truth'. 
As each training month requires features from its previous 1-3 months and ground truth for future 3-12 months, the actual timestamps used in the Feb. 2022 version of training are from `2016-01` to `2020-07`. 
A total of 31 features are compiled. We select a random 100 pixels in each of the 249 regions for training. Each row in the training table represents a historic month and a pixel. About a million rows per vegtation type are used in training.  
- Inference fusion: For each  month, Sentinel-2 data from that month and the previous 12 months is merged into a single file and stored in the merged folder corresponding to that month. 

## Machine Learning Models:
The 9 models are trainined simultaneously for 3 target months and 3 vegetation pixel types. The model names are provided in `./pipelines/veg_forecasting-ci.yml`: 
```Python
# pv_3mon: vdsm-train-pv_3mon-sc.pkl
# pv_6mon: vdsm-train-pv_6mon-sc.pkl
# pv_12mon: vdsm-train-pv_12mon-sc.pkl
# npv_3mon: vdsm-train-npv_3mon-sc.pkl
# npv_6mon: vdsm-train-npv_6mon-sc.pkl
# npv_12mon: vdsm-train-npv_12mon-sc.pkl
# bs_3mon: vdsm-train-bs_3mon-sc.pkl
# bs_6mon: vdsm-train-bs_6mon-sc.pkl
# bs_12mon: vdsm-train-bs_12mon-sc.pkl
```
The targets for training are EVI values for future 3, 6, 12 months (9 month is also included in the code but not trained).
The 31 features are selected from the climate, co2, and historic EVI changes, and the month is a category feature that is `one-hot coded` into 12 categories.
Therefore the actual feature column number is 42 before feeding into a training algorithm.

`XGBoost` is used in production for its best performance and easier interpretation. A neural network was developed in the PoC stage with comparable evaluation metrics but not used in scaling up. R2 score and MSE (mean square error) are used as metrics for model evaluation in the training stage. The million rows per vegeation type are randomly split into `80:20` for training and hold-out testing. 3-fold Cross-validation is used in the training stage (i.e., the training dataset are randomly drawn 3 times to select best models.)

### Model evaluation
We evaluate the model performance on the actual client problem in 3 complimentary ways:
1. Spatial generalisation (Pixel level): The Hold-out testing dataset described above are used for testing how well the models can predict EVI for pixels/spatial regions they have never seen before.  The R2 score is in the range of 0.88-0.91, MSE 0.001-0.004 (note that the EVI value range is 0-1, meaning 10-20% error in EVI based on RMSE). **Caution!** Because the random split didn't ensure 'held-out' of unseen dates in the training dataset,  there is information 'leaking' about the `month` feature. **The metrics quoted here are therefore only an indication of the spatial generalisation and do not reflect how accuracy the models are for a future unseen date.**

2. Performance in a future timestamp (Pixel level): To test the models' performance on dates that they never see before, we run the model on two month-stamps that the models haven't seen: 2020-08 and 2021-01, and make predictions for 2020-11, 2021-02, 2021-08; 2021-04, 07, 2022-01. The R2 score is 0.5-0.6 for the 3-month predictions and drops to below 0.5 for 6, 12 months. For our client's problem, banded EVI values are used instead of continuous values (see Section- Front end EVI to PCI conversion). 
We category the EVI values into bands of 0.2 dex and calculate the accuracy to be 0.7-0.9 for the 3-month predictions. Explanations and cautions of our model's suitabliity for predicting 3, 9, 12 months in the future are provided in Section- Recommendations and Warnings. To evaluate whether this level of R2 score and accuracy is sufficient to solve our client's problem, we refer to the PCI validation below.

3. PCI Validation (Chainage/Station level, **most relevant to the client**): 
A validation analysis was performed by comparing the Priority Clearing Indices (PCI, see Section-EVI to PCI conversion) of each Station Reference of the Predicted results with the Actual results. The below figure shows the difference in the predicted vs actual EVI values for a starting month of 2021-01. The table summaries the percentage difference `((predicted - actual) / actual)`. The results are satisfactory (92% accurate) for forecasting/planning clearing 3 months in the future, however caution must be taken when planning for clearing 6 and 12 months into the future.

<div style="width:800px; height:500px">

![PCI to EVI](/veg_forecasting/documents/PCI_vs_EVI_results.JPG)

</div>

## Batch Scoring (aka Inference)
An end-to-end automation master pipeline is built to automatically make 3, 6, 12-month predictions for each month. 
The automation master pipeline includes 3 major steps/pipelines that can be executed separately as described above and summarised below:  
 1. data ingestion (Azure functionapp at a scheduled time): check Sentinel-2 data from Digital Earth Australia each month.
 2. data fusion (AML fusion pipeline triggered by Azure functionapp): fuse Sentinel-2 with climate, fractional cover and global CO2 data, tranform the unstructured data into structured tables, 
make features match the ML training input.
 3. batch scoring (AML batch scoring pipeline triggered by the AML fusion pipeline): 
run corresponding ML models on the fused data and produce 9 csv outputs to be used by the VDSM front-end. 

In steps above, the AML pipeline `REST endpoints` are used to activate the corresponding pipelines.

### Steps to create batch scoring endpoints to be called by the fusion pipline
#### If first time running after making changes to the repo source scripts: 
 0. Check/Edit `SCORE_MODEL_VERSION` in `.env()` and make sure you use the intended model version (current best version is` 4 `as of Feb 7, 2022).
 1. If you want to publish endpoints to be included in the master pipeline, change `SCORING_AUTO_MODE` in `.env()` to `true`.
 2. In `Azure DevOps` - Pipelines, Run ``Batch Scoring`` and select the updated branch (e.g., `main`).
 3. DevOps will publish and run the Batch Scoring endpoints for 9 models (3 vegetation types times 3 month types). The endpoints can be found 
either in the AML portal ``pipeline: endpoints`` or in the terminal message print out of DevOps. 
 4. Copy and paste the endpoints to the end of the fusion script (`TBD`) for end-to-end automation.

#### Frequently wondered questions for code readers
- How are model names, versions and datasets been communicated from .env() to pipelines? <br>
 `ml_service/veg_forecasting_build_parallel_batchscore_pipeline.py` contains details.

- Where are the output scoring files? <br>
 In storage account `asartpacedevstvdsm001`, container `data`, and blobname starting with root `scoringoutput_csv/`, and `year/month/`. 
Scoring/prediction/inference files are in csv format as `pred{month}_{veg_type}.csv'.

## Training (initial setup)
The training pipeline is defined and orchestrated from this file `./pipelines/veg_forecasting-ci.yml`, which uses this file`./ml_service/pipelines/veg_forecasting_build_train_pipeline.py`
 to build and publish the three mains steps (training, evaluation, register) in the training pipeline. The pipeline then calls for python files in these 3 folders `./veg_forecasting/training/*.py, ./veg_forecasting/evaluate/*.py, ./veg_forecasting/register/*.py` to execute the steps. 

The models are registered when in the evaluation, the metrics (MSE) is better than previously registered models. We disabled this logic so that all trained models are registered. To enable this logic, please debug `line 121` (the commented out line was not working) in `./veg_forecasting/evaluate/*.py` and check the keyword `RUN_EVALUATION` to be `true` in `.env()`.

To prepare for an initial training without prior knowledge of best hyperparameters, suggest the following steps:
1. Modify XGBoost hyperparamter `parameters`  in `./veg_forecasting/training/train.py`. Comments in `line 132` of `train.py` provide a good example of the coarse range of searching
using `RandomizedSearchCV`. The total fitting rounds would be `n_iter` times `cv`. We recommend less than 100 rounds to avoid overblowing budget (UDS 400-600) as well as cloud compute sources' unexpected failure. Future improvements could incorporate AML's [hyperdrive](https://docs.microsoft.com/en-us/azure/machine-learning/how-to-tune-hyperparameters), as well as AML's power automl option.
2. Modify/check `DATASET_NAME` in `.env()` to ensure the correct datasets are used in the `./veg_forecasting/training/train_aml.py`.
3. Check `.env()` to ensure the compute clusters are what we want. Current default cluster is the minimum requirement for sufficent memory in training. 
4. In `Azure DevOps` - Pipelines, Run ``Model-Train-Register-CI`` and select the updated branch (e.g., `main`).
5. Go to sleep 🌃 and wake up to check results in the `Experiements:mlopspython` of `AML studio`.

## Re-Training
Follow the steps above, but now with some priors of the hyperparameters, you can narrow down the hyperparameter search range and do a 4-6 hr smaller tranining.

Not recommend changing the model names due to the syntax passing between model names and dataset matching (in `./veg_forecasting/training/train_aml.py`). 
When retraining the model, a new version tag is going to be automatically added. If changing model names is absolutely necessary (e.g., new features are added to train a brand new model), we recommend only changing the `'vdsm-train'` word root in `./pipelines/veg_forecasting-ci.yml`,  that way, there is no need to change the code in `./veg_forecasting/training/train_aml.py`.


## Data Drift Monitor
Azure Machine Learning dataset monitors are used together with  Application Insights to monitor data drift and help detect model performance issues. 
- Azure Machine Learning Dataset Monitors: Dataset monitor (with name `<vegtype>-mdrift-`) is rerun every month for each vegetation type with the same baseline dataset but updated target dataset (with same name).The published pipeline is `mdrift_pipeline` with initial drift object setup in `data_drift_detector_initial_setup.ipynb`.
    - Baseline dataset - the training dataset for the model based on the vegetation type
    - Target dataset - the model input data with the timestamp column `ymd-drift` that is added from TabularDataset creation with `partition_format` 
    - Drift feature - feature that is being monitored is `EVI`
- Azure Application Insights: Azure Application Insights enable the continuous monitoring of data within the resource group and notification of stakeholders and developers should concern arise.
Drift metrics are queried in the Azure Application Insights resource [aml-AppIn-spacetech](https://portal.azure.com/#@riotinto.onmicrosoft.com/resource/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourcegroups/arg-rt-pacedev-spacetech/providers/microsoft.insights/components/aml-appin-spacetech/logs)
 using Kusto Query Language (KQL). Resources on [syntax](https://squaredup.com/blog/kusto-101-a-jumpstart-guide-to-kql/) and [usage](https://docs.microsoft.com/en-us/azure/data-explorer/kusto/query/). Email is sent when the average drift magnitude across 3 months is higher than 15%.




## Error logging
High level audits of the end-to-end pipeline are logged by the `<enter module name>` program to provide high-level program status. The startup
and finish status of each phase (job) in the pipeline is recorded in an SQL database hosted on an Azure SQL server, and which indcates successful
execution or an error message. This can then be used to direct attention to detailed log files associated with the job. The logger automatically runs 
when the pipeline is run, recording the following information:  
* `job_id` and `job_name`: identifies the step in the pipeline  
* `run_id`: identifies the 'cycle' (month) in which the current job is running
* `date_time`: the time at which the status was logged
* `description`: a short message indicating the status of the job

More information on usage and configuration of the logger can be found at <>, where the `logger_user_guide.ipynb` and `readme` files
are stored.


## Unit test
Not implemented!!! Should implement in the future for best practice. 

## Computation time and cluster quota
Total Cluster Dedicated Regional vCPUs. Maximum allowed: 300.
- inference pipeline (separately triggered from DevOps): 40min - 1hr
- data fusion pipeline (separately from AML): 6-10 hr

## EVI to PCI conversion and Front-end Consumption via FME and ArcGIS


<!-- <img src="/veg_forecasting/documents/pci_evi.png" style="width: 200px" /> -->


<div style="width:900px; height:500px">

![PCI to EVI](/veg_forecasting/documents/pci_evi.png)

</div>


## Infrastructure support
Please refer to [SpaceTech Vegetation Management Solution Architecture documentation, word format](https://dev.azure.com/PACE-DevOps/_git/Tempo-SpaceTech?path=/veg_forecasting/documents/TDE%20-%20SpaceTech%20Vegetation%20Management_vFeb2022.docx&version=GBmain).


## Useful for Testing, Debugging
- Switch `SCORING_LOGGER_MODE` in `.env()` to 'true' for logging the outcome of the last step of inference.
- Switch `SCORING_TEST_MODE` in `.env()` to 'true' for using a smaller dataset for scoring test.


## Recommendations and Warnings
### Warnings
The satellite data collected has a band 'fmask' which classifies pixels as cloud, shadow, snow, water, or valid pixel. We filter out those images with greater than 25% combined of cloud, shadow, or snow pixels. 
However the fmask band is not perfect and it sometimes classifies cloudy images as valid pixels. This becomes a problem in months with a lot of storms or bushfires. 
Cloudy or smoky images may be classified as valid which results in false negative EVI values, so please use the EVI values of such months with caution.
Also, please note that when smoky images are detected by the fmask algorithm, they are often classified as snow rather than cloud.

### Recommendations
- The models are satisfactory for forecasting/planning clearing 3 months in the future, however caution must be taken when planning for clearing 6 and 12 months into the future.
- If a known area has been cleared recently, it is recommended to wait until the next image ingestion before making whole-of-network clearing plans to capture the PCI change.
- If the model prediction deviates a lot from the actual EVI values, it could signal interesting/unknown events of either the starting month when the prediction is made, or the month(s) that the predictions are made for. (e.g.,  slide 4, 2021-02 the actual EVI cannot be trusted because of snow, and smoke/bush fire)



# Contribute
## Backend Development (this Repo)
- Carter Hills (Carter.Hills@au.ey.com): KeyVault, Azure Monitor, Logger creation
- Catriona Calantzis (Catriona.Calantzis@au.ey.com): Data ingestion, merging, fusion, Azure Function
- Kenrick Setiobudi (kenrick.setiobudi@au.ey.com): Project manager, data risk management
- Paddy Muston (Paddy.Muston@au.ey.com): Scrum master, DevOps/MLOps, CI/CD, cloud deployment
- Rakesh.Sahu (Rakesh.Sahu@au.ey.com): Azure Infrastructure, Cloud Data Security (see separate documentation)
- Shin Wei Tan (shin.wei.tan@au.ey.com): AML testing/logging, Data Drift Monitor
- Tiantian.Yuan (tiantian.yuan@au.ey.com): Training/Inference, MLOps, overall data science methodology

## Front-end Development
- Callum Smith (Callum.Smith@au.ey.com): ArcGIS, FME, PowerBI,  Vegetation Risk Index Dev
- Marcel Bray (Marcel.Bray@au.ey.com): ArcGIS, FME, PowerBI, Vegetation Risk Index Dev