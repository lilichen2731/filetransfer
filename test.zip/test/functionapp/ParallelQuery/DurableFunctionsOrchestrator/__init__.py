# This function is not intended to be invoked directly. Instead it will be
# triggered by an HTTP starter function.
# Before running this sample, please:
# - create a Durable activity function (default name is "Hello")
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

import pandas as pd
import azure.durable_functions as df
# from vdsm_logger.logger import Logger
from azure.keyvault.secrets import SecretClient
from azure.identity import  ManagedIdentityCredential
from vdsm_util import get_blob_client
import traceback
from datetime import datetime

def orchestrator_function(context: df.DurableOrchestrationContext):

    month = context.get_input()['month']
    run_id = context.get_input()['run_id']

    try:
        query_df = pd.read_csv("grouped_chainage_df_5km_v2.csv")

        parallel_tasks = [context.call_activity('DataQuery', [row['name'], (month, month), [row.min_lon, row.min_lat, row.max_lon, row.max_lat], run_id]) for index, row in query_df.iterrows()]

        outputs = yield context.task_all(parallel_tasks)
        co2output = yield context.call_activity("CO2Query", [month, run_id])
        climateoutput = yield context.call_activity("ClimateQuery", [month, run_id])
        pipelineoutput = yield context.call_activity("PipelineTrigger", [month, run_id])
        
        # logger = Logger(job_id=1, run_id=run_id)
        # logger.run(description="Finished", date_time=datetime.now())

        return True

    except GeneratorExit:
        pass

    except:
        # try:
            # logger = Logger(job_id=1, run_id=run_id)
            # logger.run(description=traceback.format_exc(), date_time=datetime.now())
        # except:
        keyVaultName = "kv-spacetech001"
        KVUri = f"https://{keyVaultName}.vault.azure.net"
        credential = ManagedIdentityCredential(client_id = 'db8e6c50-4a0f-4e53-861d-fd2d6828e0d5')
        client = SecretClient(vault_url=KVUri, credential=credential)
        conn_str = client.get_secret("asartpacedevstvdsm001-connstr")

        blob_client = get_blob_client('traceback.txt', conn_str=conn_str.value)
        blob_client.upload_blob(traceback.format_exc(), overwrite=True)

        return False

main = df.Orchestrator.create(orchestrator_function)