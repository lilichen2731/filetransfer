# This function is not intended to be invoked directly. Instead it will be
# triggered by an orchestrator function.
# Before running this sample, please:
# - create a Durable orchestration function
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

import requests
from azureml.core.authentication import InteractiveLoginAuthentication
# from vdsm_logger.logger import Logger
import traceback
from azure.keyvault.secrets import SecretClient
from azure.identity import  ManagedIdentityCredential
from vdsm_util import get_blob_client

def main(input):

    month = input[0]
    run_id = input[1]

    try:

        interactive_auth = InteractiveLoginAuthentication()
        auth_header = interactive_auth.get_authentication_header()
        rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-spacetech/providers/Microsoft.MachineLearningServices/workspaces/aml-ws-spacetech001/PipelineRuns/PipelineSubmit/ee1d8b2c-3aaf-4a3d-819a-53d51211f77b'
        response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "infer_merge", "ParameterAssignments": {"month": month}})


        return True

    except:

        # logger = Logger(job_id=1, description=traceback.format_exc())
        # logger.run()

        keyVaultName = "kv-spacetech001"
        KVUri = f"https://{keyVaultName}.vault.azure.net"
        credential = ManagedIdentityCredential(client_id = 'db8e6c50-4a0f-4e53-861d-fd2d6828e0d5')
        client = SecretClient(vault_url=KVUri, credential=credential)
        conn_str = client.get_secret("asartpacedevstvdsm001-connstr")

        blob_client = get_blob_client('logs/pipeline_traceback.txt', conn_str=conn_str.value)
        blob_client.upload_blob(traceback.format_exc(), overwrite=True)

        return False

