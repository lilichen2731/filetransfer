import datetime
import logging

import azure.durable_functions as df
import azure.functions as func
import datetime

async def main(req: func.TimerRequest, starter: str) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if req.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    client = df.DurableOrchestrationClient(starter)
    this_month = datetime.date.today().replace(day=1)
    last_month = this_month - datetime.timedelta(days=1)
    month = str(last_month)[:7]

    # instance_id = await client.start_new(req.route_params["functionName"], client_input={'month' : month, 'run_id' : logger.run_id})
    instance_id = await client.start_new("DurableFunctionsOrchestrator", client_input={'month' : month, 'run_id' : -1})
    
    logging.info(f"Started orchestration with ID = '{instance_id}'.")

    return client.create_check_status_response(req, instance_id)