# This function is not intended to be invoked directly. Instead it will be
# triggered by an orchestrator function.
# Before running this sample, please:
# - create a Durable orchestration function
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

# import logging
import cdsapi
import xarray as xr
from fsspec.implementations.http import HTTPFileSystem
import json
from azure.storage.blob import BlobServiceClient
import traceback
import pickle
from vdsm_util import get_blob_client
from azure.keyvault.secrets import SecretClient
from azure.identity import  ManagedIdentityCredential
# from vdsm_logger.logger import Logger
import traceback
from datetime import datetime

def main(input):

    month = input[0]
    run_id = input[1]

    try:

        years = []
        for year in range(2015, int(month[:4])+1):
            years.append(str(year))

        keyVaultName = "kv-spacetech001"
        KVUri = f"https://{keyVaultName}.vault.azure.net"
        credential = ManagedIdentityCredential(client_id = 'db8e6c50-4a0f-4e53-861d-fd2d6828e0d5')
        client = SecretClient(vault_url=KVUri, credential=credential)
        conn_str = client.get_secret("asartpacedevstvdsm001-connstr")

        # conn_str = "DefaultEndpointsProtocol=https;AccountName=asartsecurestgvdsm;AccountKey=MOnbuCD5UzCoYZB2tzZLJVBBhr60VmazVZiJlPKyz48NH0XhdyUux67seu96Nbn+8nhlSyrssH8wvQj87YVFqA==;EndpointSuffix=core.windows.net"

        c = cdsapi.Client(url='https://cds.climate.copernicus.eu/api/v2', key='99370:026f9b3f-0e9c-4079-bf88-b8c2336a3c9a')

        response = c.retrieve(
            'reanalysis-era5-land-monthly-means',
            {
                'product_type': 'monthly_averaged_reanalysis',
                'variable': [
                    '10m_u_component_of_wind', '10m_v_component_of_wind', '2m_temperature',
                    'leaf_area_index_high_vegetation', 'leaf_area_index_low_vegetation', 'skin_reservoir_content',
                    'surface_net_solar_radiation', 'surface_pressure', 'total_evaporation',
                    'total_precipitation', 'volumetric_soil_water_layer_1',
                ],
                'year': years,
                'month': [
                    '01', '02', '03',
                    '04', '05', '06',
                    '07', '08', '09',
                    '10', '11', '12',
                ],
                'time': '00:00',
                'area': [
                    -20, 113, -30,
                    122.5,
                ],
                'format': 'netcdf',
            },
            None)

        ds_env = xr.open_dataset(HTTPFileSystem().open(response.location))

        pickled_ds = pickle.dumps(ds_env)

        blob_client = get_blob_client('climate/{}.pkl'.format(month), conn_str=conn_str.value)
        # blob_client = get_blob_client('climate/{}.pkl'.format(month), conn_str=conn_str)
        blob_client.upload_blob(pickled_ds, overwrite=True)

        return True

    except:
        # try:
        #     logger = Logger(job_id=1, run_id=run_id)
        #     logger.run(description=traceback.format_exc(), date_time=datetime.now())
        # except:
        keyVaultName = "kv-spacetech001"
        KVUri = f"https://{keyVaultName}.vault.azure.net"
        credential = ManagedIdentityCredential(client_id = 'db8e6c50-4a0f-4e53-861d-fd2d6828e0d5')
        client = SecretClient(vault_url=KVUri, credential=credential)
        conn_str = client.get_secret("asartpacedevstvdsm001-connstr")

        blob_client = get_blob_client('logs/climate_traceback.txt', conn_str=conn_str.value)
        blob_client.upload_blob(traceback.format_exc(), overwrite=True)

        return False
