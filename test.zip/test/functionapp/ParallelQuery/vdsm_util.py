"""Custom functions used in the VDSM data fusion steps.
"""
from azure.storage.blob import BlobServiceClient, __version__
import geopandas as gpd
import affine
import xarray as xr
from rasterio.features import rasterize
from io import StringIO
import numpy as np

account_details = {"account_name": "asartpacedevstvdsm001", "container_name": "data"}

def get_blob_client(filename:str, conn_str=None, account_details=account_details):
    """ Purpose: initiate a client for writing into a blob location.
        Parameters:
        --------
        out_file: string, 
                out_put filename to write to a blob.
        parent_dir: string, optional
                parent directory on the blob. Default is odc_vm_data/odc_outputs for this VM created by admin.
    """
    
    blob_service_client = BlobServiceClient.from_connection_string(conn_str)
    blob_client = blob_service_client.get_blob_client(container=account_details["container_name"], blob=filename)
    return blob_client

def get_blobnames(search_dir='./', conn_str=None, account_details=account_details):
    """ Purpose: list all files under the search directory of a  blob location.
        Parameters:
        --------
        search_dir: str, optional
             searching directory on the blob. 
             Default is odc_vm_data for this VM created by admin acc.
        Return:
             A blob container service
        Examples:
        ### Test deleting files from blob
                blob_cont = get_blobnames()
                file_del = '.require_vmcopy.txt'
                try:
                     blob_cont.delete_blob(file_del)
                except:
                    print('no such file')   
                       
    """
    blob_service_client = BlobServiceClient.from_connection_string(conn_str)
    container_client = blob_service_client.get_container_client(account_details["container_name"])
    blob_list = container_client.list_blobs()
    return_list = []
    for blob in blob_list:
        # list all files under the blob directory 'odc_vm_data'
        if search_dir in blob.name:
            return_list.append(blob.name)
            # print(blob.name)

    return return_list

def cloud_cover_filter(ds, threshold=0.25, mask_path='static/RTiO_ChainageAreas_1KM_30M.json', conn_str=None):

    blob_client = get_blob_client(filename=mask_path, conn_str=conn_str)
    gdf = gpd.read_file(StringIO(blob_client.download_blob().content_as_text()))
    gdf_3577 = gdf.to_crs("EPSG:3577")
    mask = get_mask_sh(ds, gdf_3577)
    ds = ds.where(mask)

    timestamps_to_drop = []

    for timestamp in ds.time.data:
        fmask_vals = ds.sel(time=timestamp)['fmask'].data.flatten()
        fmask_vals = fmask_vals[~np.isnan(fmask_vals)]
        unique, counts = np.unique(fmask_vals, return_counts=True)
        fmask_dict = dict(zip(unique, counts))
        cloud = 0
        shadow = 0
        snow = 0
        try:
            cloud = fmask_dict[2]
        except:
            pass
        try:
            shadow = fmask_dict[3]
        except:
            pass
        try:
            snow = fmask_dict[4]
        except:
            pass
        percent = (cloud + shadow + snow)/(len(fmask_vals))
        if percent > threshold:
            timestamps_to_drop.append(timestamp)

    for timestamp in timestamps_to_drop:
        ds = ds.drop_sel(time=timestamp)

    return ds

def get_mask_sh(ds, gdf):
    try:
        crs = ds.crs
    except:
        crs = "epsg:3577"
    transform=affine.Affine(10.0, 0.0, ds.coords['x'].data.min()-5,
                        0.0, -10.0, ds.coords['y'].data.max()+5)
    y, x = len(ds.coords['y']), len(ds.coords['x'])
    try:
        gdf_reproj = gdf.to_crs(crs=crs)
    except:
        gdf_reproj = gdf.to_crs(crs=str(crs))
    shapes = gdf_reproj.geometry
    arr = rasterize(shapes=shapes,
                    out_shape=(y, x),
                    transform=transform)
    xarr = xr.DataArray(arr,
                        coords=(ds.coords['y'], ds.coords['x']),
                        dims=('y', 'x'),
                        attrs=ds.attrs)
    return xarr