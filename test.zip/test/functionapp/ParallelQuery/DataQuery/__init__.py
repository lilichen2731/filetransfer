import logging
from odc.stac import load as stac_load
from pystac_client import Client
from datacube.utils.aws import configure_s3_access
import pickle
from vdsm_util import get_blob_client, cloud_cover_filter
from azure.keyvault.secrets import SecretClient
from azure.identity import  ManagedIdentityCredential
# from vdsm_logger.logger import Logger
import traceback
import pystac_client
import time
import random

def main(input):

    run_id = input[3]

    try:

        keyVaultName = "kv-spacetech001"
        KVUri = f"https://{keyVaultName}.vault.azure.net"
        credential = ManagedIdentityCredential(client_id = 'db8e6c50-4a0f-4e53-861d-fd2d6828e0d5')
        client = SecretClient(vault_url=KVUri, credential=credential)
        conn_str = client.get_secret("asartpacedevstvdsm001-connstr")

        # conn_str = "DefaultEndpointsProtocol=https;AccountName=asartsecurestgvdsm;AccountKey=MOnbuCD5UzCoYZB2tzZLJVBBhr60VmazVZiJlPKyz48NH0XhdyUux67seu96Nbn+8nhlSyrssH8wvQj87YVFqA==;EndpointSuffix=core.windows.net"

        retrieved = False
        cancelled = False

        while not retrieved and not cancelled:

            try:

                configure_s3_access(aws_unsigned=True, region_name='ap-southeast-2')

                catalog = Client.open("https://explorer-aws.dea.ga.gov.au/stac/")

                bbox=input[2]
                start_date=input[1][0]
                end_date=input[1][1]
                name=input[0]

                query = catalog.search(
                    collections=["s2a_ard_granule", "s2b_ard_granule"],
                    datetime=start_date+'/'+end_date, 
                    bbox=bbox
                )

                items = list(query.get_items())
                logging.info(f"Found: {len(items):d} datasets")

                ds = stac_load(
                    items,
                    output_crs='EPSG:3577',
                    resolution=10,
                    groupby="solar_day",
                    bbox=bbox,
                    bands=['nbart_red', 'nbart_green', 'nbart_blue', 'nbart_nir_1', 'fmask'],
                    skip_broken_datasets=True
                )

                ds = cloud_cover_filter(ds, conn_str=conn_str.value)
                # removing parts of the image that weren't included in the satellite capture
                ds = ds.where(ds['nbart_red'] != 0)  
                pickled_ds = pickle.dumps(ds)

                blob_client = get_blob_client('{}/{}/staging/{}_S2.pkl'.format(start_date[:4], start_date[5:], name), conn_str=conn_str.value)
                # blob_client = get_blob_client('{}/{}/staging/{}_S2.pkl'.format(start_date[:4], start_date[5:], name), conn_str=conn_str)
                blob_client.upload_blob(pickled_ds, overwrite=True)

                retrieved = True

            except pystac_client.exceptions.APIError:
                time.sleep(random.randint(10,120))

            except:
                cancelled = True

        return True

    except:
        # try:
        #     logger = Logger(job_id=1, run_id=run_id)
        #     logger.run(description=traceback.format_exc(), date_time=datetime.now())
        # except:
        keyVaultName = "kv-spacetech001"
        KVUri = f"https://{keyVaultName}.vault.azure.net"
        credential = ManagedIdentityCredential(client_id = 'db8e6c50-4a0f-4e53-861d-fd2d6828e0d5')
        client = SecretClient(vault_url=KVUri, credential=credential)
        conn_str = client.get_secret("asartpacedevstvdsm001-connstr")

        blob_client = get_blob_client('logs/data_traceback.txt', conn_str=conn_str.value)
        blob_client.upload_blob(traceback.format_exc(), overwrite=True)

        return False