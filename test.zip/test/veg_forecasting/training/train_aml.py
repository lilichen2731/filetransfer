"""
Copyright (C) Microsoft Corporation. All rights reserved.​
 ​
Microsoft Corporation (“Microsoft”) grants you a nonexclusive, perpetual,
royalty-free right to use, copy, and modify the software code provided by us
("Software Code"). You may not sublicense the Software Code or any use of it
(except to your affiliates and to vendors to perform work on your behalf)
through distribution, network access, service agreement, lease, rental, or
otherwise. This license does not purport to express any claim of ownership over
data you may have shared with Microsoft in the creation of the Software Code.
Unless applicable law gives you more rights, Microsoft reserves all other
rights not expressly granted herein, whether by implication, estoppel or
otherwise. ​
 ​
THE SOFTWARE CODE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
MICROSOFT OR ITS LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THE SOFTWARE CODE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
"""
from azureml.core.run import Run
from azureml.core import Dataset, Datastore, Workspace
import os
import argparse
import joblib
import json
from train import split_data, train_model, get_model_metrics, get_model_metrics_all
import re

def register_dataset(
    aml_workspace: Workspace,
    dataset_name: str,
    datastore_name: str,
    file_path: str
) -> Dataset:
    datastore = Datastore.get(aml_workspace, datastore_name)
    dataset = Dataset.Tabular.from_delimited_files(path=(datastore, file_path))
    dataset = dataset.register(workspace=aml_workspace,
                               name=dataset_name,
                               create_new_version=True)

    return dataset


def main():
    print("Running train_aml.py")
    run = Run.get_context()

    parser = argparse.ArgumentParser("train")
    parser.add_argument(
        "--model_name",
        type=str,
        help="Name of the Model",
        default="anonymous_model.pkl",
    )

    parser.add_argument(
        "--step_output",
        type=str,
        help=("output for passing data to next step")
    )

    parser.add_argument(
        "--dataset_version",
        type=str,
        help=("dataset version")
    )

    parser.add_argument(
        "--data_file_path",
        type=str,
        help=("data file path, if specified,\
               a new version of the dataset will be registered")
    )

    parser.add_argument(
        "--caller_run_id",
        type=str,
        help=("caller run id, for example ADF pipeline run id")
    )

    parser.add_argument(
        "--dataset_name",
        type=str,
        help=("Dataset name. Dataset must be passed by name\
              to always get the desired dataset version\
              rather than the one used while the pipeline creation")
    )

    args = parser.parse_args()

    # format of the model_name, e.g. vdsm-train-pv_3mon.pkl
    print("Argument [model_name]: %s" % args.model_name)
    model_name = args.model_name
    assert isinstance(model_name, str)
    model_str = re.split('-', model_name)[2].split('_')
    veg_type = model_str[0]
    month_str = re.findall('[0-9]+', model_str[1])
    month_int = int(month_str[0])
    assert isinstance(month_int, int)
    # print(f"Argument [veg type and month_int]: {veg_type} {month_int}")
    run.log('veg type', veg_type)
    run.log('month trained', month_int) 

    input_datasetname = args.dataset_name
    ### Take the input dataset name and replace with veg_type
    
    # 1. use this for scale up training
    # dataset_name = f'training_{veg_type}_folderv0'    # hard code way
    veg_type_str = f'{veg_type}'    
    dataset_name = input_datasetname.replace('vegtype', veg_type_str)

    # 2. use this for testing only, a small dataset
    # veg_type = 'npv'
    # dataset_name = f'vdsm_{veg_type}_local_test'

    print("Argument [dataset_name passed]: %s" % dataset_name)

    print("Argument [dataset_version passed]: %s" % args.dataset_version)
    dataset_version = args.dataset_version

    ### This caller_run_id is not used in the code, just print
    print("Argument [caller_run_id, not used]: %s" % args.caller_run_id)
    print("Argument [data_file_path, not used]: %s" % args.data_file_path)
    data_file_path = args.data_file_path

    ### what is the step_output_path 
    print("Argument [step_output, not used]: %s" % args.step_output)
    step_output_path = args.step_output

    # print("Getting training parameters")
    ### VDSM no longer uses this json, params hard-coded in train.py
    ###        INVALID     ####
    # Load the training parameters from the parameters file
    with open("parameters.json") as f:
        pars = json.load(f)
    try:
        train_args = pars["training"]
        selected_target_mon = pars['model_selection']
    except KeyError:
        print("Could not load training values from file")
        train_args = {}
    # Log the training parameters
    # print(f"Parameters: {train_args}")
    # run.log()
    # for (k, v) in train_args.items():
    #     run.log(k, v)
    #     run.parent.log_list(k, v)

    # Get the dataset
    if (dataset_name):
        if (data_file_path == 'none'):
            dataset = Dataset.get_by_name(run.experiment.workspace, dataset_name, dataset_version)  # NOQA: E402, E501
        else:
            dataset = register_dataset(run.experiment.workspace,
                                       dataset_name,
                                       os.environ.get("DATASTORE_NAME"),
                                       data_file_path)
    else:
        e = ("No dataset provided")
        print(e)
        raise Exception(e)

    # Link dataset to the step run so it is trackable in the UI
    run.input_datasets['training_data'] = dataset
    run.parent.tag("dataset_id", value=dataset.id)

    # Split the data into test/train
    df = dataset.to_pandas_dataframe()
    print(f'***** check the input df shape before split_data {df.shape}')
    print(f'***** training veg_month passed {veg_type}_{month_int}')

    data, feature_names = split_data(df, month_flt=month_int)

    # Train the model
    print(f'***** check the input shape of train_model {data["train"]["X"].shape} and {data["train"]["y"].shape}')
    model = train_model(data, train_args, feature_names=feature_names)

    # Evaluate and log the metrics returned from the train function
    metrics_all = get_model_metrics_all(model, data)
    metrics = get_model_metrics(model, data)

    run.log('metrics rse, r2', metrics_all)
    # run.log_list('metrics rse, r2', metrics)
    # for (k, v) in metrics.items():
    #     # run.log(k, v)
    #     run.log_list(k, v)
    #     run.parent.log_list(k, v)

    # Pass model file to next step
    os.makedirs(step_output_path, exist_ok=True)
    model_output_path = os.path.join(step_output_path, model_name)
    joblib.dump(value=model, filename=model_output_path)

    # Also upload model file to run outputs for history
    os.makedirs('outputs', exist_ok=True)
    output_path = os.path.join('outputs', model_name)
    joblib.dump(value=model, filename=output_path)

    run.tag("run_type", value="train")
    print(f"tags now present for run: {run.tags}")

    run.complete()


if __name__ == '__main__':
    main()