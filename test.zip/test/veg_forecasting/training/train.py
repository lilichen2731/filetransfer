# -*- coding: utf-8 -*-
import os
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score, KFold
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.metrics import r2_score
# import xgboost as xgb
import seaborn as sns
from xgboost import XGBRegressor
import numpy as np
from azureml.core.run import Run
import matplotlib.pyplot as plt
from calendar import month_abbr


def split_data(df, month_flt=3):
    """Create train/test split dataset from our veg_forecast pre-processed dataframe.

    Parameters
    ----------
    df : dataframe
        must be in the exact format from a veg_forecast data pre-processing step.
        
    month_flt : int
         (Default value = 3) month number for prediction. Current choices: 3, 6, 12.

    Returns
    -------
    data: dataframe
         with 'train' and 'test' columns
         
    To-Do: 
        Re-package for multiple month_flt choices. 
        Enable 12 in month_flt and update Warning msg below.
    """
    run = Run.get_context()

    df_use = df.copy() 
    df_use.dropna(inplace=True)

    if df_use.columns[0] != "year":
        df_use.drop(columns=df_use.columns[0], axis=1, inplace=True)
    dropped_names = ["lat_4326", "lon_4326"]
    df_use.drop(dropped_names, axis=1, inplace=True)

    ### Select ground truth column(s)
    gr_truth_cols = ['actual_3m', 'actual_6m', 'actual_9m', 'actual_12m']
    df_features = df_use.drop(gr_truth_cols, axis=1)
    df_truths = df_use[gr_truth_cols]
    feature_names = df_features.columns.values[2:]
    run.log('Features used:', feature_names)
    print('Features used:', feature_names)
    ### Drop the Year column as it cannot be a feature in forecasting models
    X = df_features.iloc[:, 1:].values

    if month_flt == 3:
        y_m = df_truths.iloc[:, 0].values
    elif month_flt == 6:
        y_m = df_truths.iloc[:, 1].values
    elif month_flt == 9:
        y_m = df_truths.iloc[:, 2].values
    elif month_flt == 12:
        y_m = df_truths.iloc[:, 3].values
    else:
        print('YOUR REQUEST NOT VALID ERROR: Current model can only predict 3, 6, 9, 12 months')

    print(f'!!!Debugging!! --- checking X.shape before onehot, {X.shape}')
    ### Encode categorical columns
    ct = ColumnTransformer(transformers=[('encoder', OneHotEncoder(sparse=False), [0])], remainder='passthrough')
    X = np.array(ct.fit_transform(X))
    print(f'!!!Debugging!! --- checking X.shape after onehot, {X.shape}')

    ### split the data into training and hand-out (testing):
    X_train, X_test, y_train, y_test = train_test_split(X, y_m, test_size=0.2, random_state=123)
    data = {"train": {"X": X_train, "y": y_train},
            "test": {"X": X_test, "y": y_test}}

    run.complete()    
    return data, feature_names


def train_model(data, model_args, feature_names=None):
    """Train the model with model_args from parameters.json, Return the model.

    Parameters
    ----------
    data :  A dataframe from train.split_data()
        
    model_args [not used in VDSM here]: dictionary, model arguments
        Read from /veg_forecasting/parameters.json

    feature_names: an feature name array for plotting purpose
    Returns
    -------
    A trained model.
    
    To-DO:
       Add logic for calling different models such as automl and our customised NN.
       Ideally using keywords from model_args.
    """
    run = Run.get_context()

    xgb1 = XGBRegressor(nthread=-1)

    # parameters = {  # 'nthread':[12], # max number of thread that can be used during training
    #           'objective':['reg:squarederror'],
    #           'learning_rate': [0.05], #so called `eta` value
    #           'max_depth': [12],    # default 6, higher = more complex, cause overfit
    #           'min_child_weight': [4],  # default 1, higher = prevent overfit
    #           'subsample': [0.8],   # default 1, smaller = prevent overfit
    #           'colsample_bytree': [1],  # default 1
    #           'gamma': [0],   # default 0, larger = more conservative
    #           'lambda': [1],    # default 1, as Ridge, larger=more conservative
    #           'alpha': [0],     # default 0, as Lasso, larger=more conservetive
    #           'n_estimators': [500]}

    # reg_model = GridSearchCV(xgb1,
    #                     parameters,
    #                     cv=3,
    #                     n_jobs=-1,
    #                     verbose=3)

    ### To fix: try train_model(data, **model_args), or without ** or just * below
#     reg_model = xgb_grid(**model_args)
    # reg_model = GridSearchCV(xgb1, **model_args, cv=3, n_jobs=-1, verbose=2)


    # parameters = {'objective':['reg:squarederror'],
    #           'learning_rate': [0.012, 0.016, 0.025, 0.03], # 0.01-0.5, so called `eta` value
    #           'max_depth': [18],    # default 6, 2-30 higher = more complex, cause overfit
    #           'min_child_weight': [4, 8, 16],  # default 1, 1-100, higher = prevent overfit
    #           'subsample': [0.8],   # default 1, 0.1-1, for data, smaller = prevent overfit
    #           'colsample_bytree': [1],  # default 1, 0.1-1, for feature sel also 'colsample_bylevel'
    #           'gamma': [0],   # default 0, larger = more conservative
    #           'lambda': [1],    # default 1, as Ridge, larger=more conservative
    #           'alpha': [0],     # default 0, as Lasso, larger=more conservetive
    #           'n_estimators': [300, 400, 600, 800]}  # default 100, 10-1000}

####  Best parameter range for models run Dec 24 2021 - Feb 2, 2022
    parameters = {'objective':['reg:squarederror'],
              'learning_rate': [0.05], # 0.01-0.5, so called `eta` value
              'max_depth': [18],    # default 6, 2-30 higher = more complex, cause overfit
              'min_child_weight': [4],  # default 1, 1-100, higher = prevent overfit
              'subsample': [0.8],   # default 1, 0.1-1, for data, smaller = prevent overfit
              'colsample_bytree': [0.8],  # default 1, 0.1-1, for feature sel also 'colsample_bylevel'
              'gamma': [0],   # default 0, larger = more conservative
              'lambda': [1],    # default 1, as Ridge, larger=more conservative
              'alpha': [0],     # default 0, as Lasso, larger=more conservetive
              'n_estimators': [500]}  # default 100, last best 480, current best 500; 10-1000}

    reg_model = RandomizedSearchCV(xgb1,
                            param_distributions=parameters,
                            scoring='r2',
                            n_iter=1,
                            cv=3,
                            n_jobs=-1,
                            verbose=3)

  
    reg_model.fit(data["train"]["X"], data["train"]["y"])
    print('TT testing --1set xgbBest para:', reg_model.best_params_)
    run.log('Best para:', reg_model.best_params_)
    
    best_model = reg_model.best_estimator_

    run.log('Feature importance:', best_model.feature_importances_)
    print('Feature importance:', best_model.feature_importances_)
    ### make plots for feature importance
    
    plt.rcParams['figure.figsize'] = [6, 8]
    numx = data["test"]["X"].shape[1]

    f_names = [None]*numx
    f_names[0:12]  = month_abbr[1:]
    f_names[12:] = feature_names
    feat_importances = pd.Series(best_model.feature_importances_, index=f_names)
    feat_importances.nlargest(15).plot(kind='barh')
    _ = plt.xlabel('Relative importance')
    _ = plt.title('XGBoost Top15 Features')
    run.log_image('Plot', plot=plt) 
    run.complete()
    return best_model


def get_model_metrics_all(model, data):
    """Evaluate the user-defined metrics for the model.

    Parameters
    ----------
    model : A trained model from train.train_model()
        
    data : A dataframe from train.split_data()
        
    Returns
    -------
    metrics: dictionary with user defined metrics.

    """
    preds = model.predict(data["test"]["X"])
    mse = mean_squared_error(data["test"]["y"], preds)
    r2 = r2_score(data["test"]["y"], preds)
    metrics = {"mse": mse, 
              "r2": r2}
    return metrics

# Evaluate the metrics for the model
def get_model_metrics(model, data):
    preds = model.predict(data["test"]["X"])
    mse = mean_squared_error(preds, data["test"]["y"])
    metrics = {"mse": mse}
    return metrics

# ignored for module calls in the aml pipeline.
def main():
    """Test the train.py using a simple local file and parameters. 
    """
    print("Do nothing: Running train.py separately")

    # # Define training parameters
    # model_args = {"n_estimators": 450}

    # # Load the training data as dataframe
    # data_dir = "data"
    # data_file = os.path.join(data_dir, 'veg_train_example.csv')
    # train_df = pd.read_csv(data_file)

    # data = split_data(train_df, month_flt=3)

    # # Train the model
    # model = train_model(data, model_args)

    # # Log the metrics for the model
    # metrics = get_model_metrics(model, data)
    # for (k, v) in metrics.items():
    #     print(f"{k}: {v}")


if __name__ == '__main__':
    main()
