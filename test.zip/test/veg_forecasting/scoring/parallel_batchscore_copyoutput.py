"""
Copyright (C) Microsoft Corporation. All rights reserved.​
 ​
Microsoft Corporation (“Microsoft”) grants you a nonexclusive, perpetual,
royalty-free right to use, copy, and modify the software code provided by us
("Software Code"). You may not sublicense the Software Code or any use of it
(except to your affiliates and to vendors to perform work on your behalf)
through distribution, network access, service agreement, lease, rental, or
otherwise. This license does not purport to express any claim of ownership over
data you may have shared with Microsoft in the creation of the Software Code.
Unless applicable law gives you more rights, Microsoft reserves all other
rights not expressly granted herein, whether by implication, estoppel or
otherwise. ​
 ​
THE SOFTWARE CODE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
MICROSOFT OR ITS LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THE SOFTWARE CODE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
"""

import argparse
import os
from azure.storage.blob import BlobClient, BlobServiceClient, ContainerClient, __version__
from azure.storage.blob import generate_blob_sas, AccountSasPermissions
from datetime import datetime, timedelta, date, timezone
import pandas as pd
import re
import dateutil.relativedelta as dtrel

# from ml_service.util.manage_environment import get_environment
from ml_service.util.env_variables import Env
from ml_service.util.vdsm_logger import Logger

from azureml.core import (
    Workspace,
    Dataset,
    Datastore,
    RunConfiguration,
)

from azureml.core.run import Run

# test logger
from ml_service.util.vdsm_logger import Logger
import traceback
import socket
#

def parse_args():
    """This is not used for now"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--output_path", type=str, default=None)
    parser.add_argument("--scoring_datastore", type=str, default=None)
    parser.add_argument("--score_container", type=str, default=None)
    parser.add_argument("--scoring_datastore_key", type=str, default=None)
    parser.add_argument("--scoring_output_filename", type=str, default=None)

    return parser.parse_args()


def write_blob_client(out_file:str, parent_dir='./', conn_str=None, account_details=None):
    """ Purpose: initiate a client for writing into a blob location.
        Parameters:
        --------
        out_file: string, 
                out_put filename to write to a blob.
        parent_dir: string, optional
                parent directory on the blob. Default is odc_vm_data/odc_outputs for this VM created by admin.
    """
    
    blob_service_client = BlobServiceClient.from_connection_string(conn_str)
    blob_client = blob_service_client.get_blob_client(container=account_details["containerName"], blob=parent_dir+out_file)
    return blob_client

def copy_output(args):
    """Post process the output of parallel run and copy the csv to custom blob"""

    env = Env()
    try:
        if (env.scoring_logger_mode).lower() == "true":
            # Print IP Address
            hostname = socket.gethostname()   
            IPAddr = socket.gethostbyname(hostname)   
            print("Batchscore Host Name is:" + hostname)   
            print("Batchscore Pipeline in IP Address is:" + IPAddr)
            logger = Logger(job_id=4, description="test IP start inference post process")
            logger.run()
        ### to do add some arguments that can be pass on here
        model_name_used = args.model_name
        model_version_used = args.model_version
        pipe_outputpath = args.output_path

        model_str = re.split('-', model_name_used)[2].split('_')
        veg_type = model_str[0]
        month_str = re.findall('[0-9]+', model_str[1])
        month = int(month_str[0])   # model predicted month


        if (env.scoring_auto_mode).lower() == "false":
            f_year = env.scoring_manual_year
            f_prev_month = env.scoring_manual_month
        else:
            f_year = (datetime.today() + dtrel.relativedelta(months=-1)).year
            f_prev_month = (datetime.today() + dtrel.relativedelta(months=-1)).month

        if (env.scoring_test_mode).lower() == "true":
            save_csvfolder = f'testmode_scoreout_csv/{f_year}/{f_prev_month}'
        else:
            scoring_prefix = env.scoring_datastore_output_filename_prefix
            save_csvfolder = f'{scoring_prefix}/{f_year}/{f_prev_month}'

            # save_csvfolder = f'scoringoutput_csv/{f_year}/{f_prev_month}'
        
        str_pred = f'pred_{month}mon'
        col_names = [
            'chainage_name', 'latitude', 'longitude', 'year','month1','month2','month3','month4','month5','month6',	'month7','month8','month9',	'month10','month11','month12',
            'evi', 'evi_prev',	'u10',	'u10_prev',	'v10',	'v10_prev',	't2m',	't2m_prev',	'lai_lv','lai_lv_prev','src','src_prev','ssr','ssr_prev',	
            'sp','sp_prev','e',	'e_prev','tp','tp_prev','tp_prev2',	'tp_prev3',	'swvl1','swvl1_prev','co2',	'co2_prev',	
            'season_ch_3mon','season_ch_6mon','season_ch_9mon',	'season_ch_12mon',	str_pred]

        df = pd.read_csv(os.path.join(args.output_path, "parallel_run_step.txt"), delimiter=" ", header=None)
        assert len(col_names) == df.shape[1]
        df.columns = col_names

    #   implement keyvault to custom blob below
    #   If want to change the output storage account to be different than scoring data input, then change below
        run = Run.get_context()
        account_details = {"accountName": env.scoring_datastore_storage_name, "containerName": env.scoring_datastore_output_container}
        conn_str = run.get_secret(env.scoring_datastore_connstr)

        save_csvfile = 'pred{}_{}.csv'.format(month, veg_type)
        save_csvpath = os.path.join(save_csvfolder, save_csvfile)
        blob_client = write_blob_client(save_csvpath, '', conn_str=conn_str, account_details=account_details)

        output = df.to_csv(index=False, encoding='utf-8', header=True)
        blob_client.upload_blob(output, overwrite=True, blob_type='BlockBlob')
        if (env.scoring_logger_mode).lower() == "true":
            logger = Logger(job_id=4, description="test IP end inference post process")
            logger.run()
            
    except Exception:
        if (env.scoring_logger_mode).lower() == "true":
            logger = Logger(job_id=4, description=traceback.format_exc())
            logger.run()
        else:
            print('Exception raised in parallel_batchscore_copyoutput.py ...')



if __name__ == "__main__":
    # args = parse_args()
    # Get parameters
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", type=str, dest='model_name', help='input model name')
    parser.add_argument("--model_version", type=int, dest='model_version', help='input model version, if None return latest')
    parser.add_argument("--output_path", type=str, dest='output_path', help="Pipeline data for output datastore loc")

    # args = parser.parse_args()
    args, _ = parser.parse_known_args()

    print('PRINTING: finding pipeline data outputpath--->', args.output_path)
    if (
        args.output_path is None
        # or args.output_path.strip() == ""
    ):
        print("Missing Pipeline data args.output_path ")
    else:
        copy_output(args)
