"""
Copyright (C) Microsoft Corporation. All rights reserved.​
 ​
Microsoft Corporation (“Microsoft”) grants you a nonexclusive, perpetual,
royalty-free right to use, copy, and modify the software code provided by us
("Software Code"). You may not sublicense the Software Code or any use of it
(except to your affiliates and to vendors to perform work on your behalf)
through distribution, network access, service agreement, lease, rental, or
otherwise. This license does not purport to express any claim of ownership over
data you may have shared with Microsoft in the creation of the Software Code.
Unless applicable law gives you more rights, Microsoft reserves all other
rights not expressly granted herein, whether by implication, estoppel or
otherwise. ​
 ​
THE SOFTWARE CODE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
MICROSOFT OR ITS LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THE SOFTWARE CODE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
"""

import numpy as np
import pandas as pd
import joblib
import sys
import argparse
from typing import List
from util.model_helper import get_model
from azureml.core import Model
# from score import prep_score_data
from azureml.core.run import Run
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from azureml_user.parallel_run import EntryScript
# from util.blob_trim import 
model = None

from azure.storage.blob import BlobClient, BlobServiceClient, ContainerClient, __version__
from azure.storage.blob import generate_blob_sas, AccountSasPermissions
from datetime import datetime, timedelta, date, timezone
import os
import json

def parse_args() -> List[str]:
    """
    The AML pipeline calls this file with a set of additional command
    line arguments whose names are not documented. As such using the
    ArgumentParser which necessitates that we supply the names of the
    arguments is risky should those undocumented names change. Hence
    we parse the arguments manually.

    :returns: List of model filters

    :raises: ValueError
    """
    model_name_param = [
        (sys.argv[idx], sys.argv[idx + 1])
        for idx, itm in enumerate(sys.argv)
        if itm == "--model_name"
    ]

    if len(model_name_param) == 0:
        raise ValueError(
            "Model name is required but no model name parameter was passed to the script"  # NOQA: E501
        )

    model_name = model_name_param[0][1]

    model_version_param = [
        (sys.argv[idx], sys.argv[idx + 1])
        for idx, itm in enumerate(sys.argv)
        if itm == "--model_version"
    ]
    model_version = (
        None
        if len(model_version_param) < 1
        or len(model_version_param[0][1].strip()) == 0  # NOQA: E501
        else model_version_param[0][1]
    )

    model_tag_name_param = [
        (sys.argv[idx], sys.argv[idx + 1])
        for idx, itm in enumerate(sys.argv)
        if itm == "--model_tag_name"
    ]
    model_tag_name = (
        None
        if len(model_tag_name_param) < 1
        or len(model_tag_name_param[0][1].strip()) == 0  # NOQA: E501
        else model_tag_name_param[0][1]
    )

    model_tag_value_param = [
        (sys.argv[idx], sys.argv[idx + 1])
        for idx, itm in enumerate(sys.argv)
        if itm == "--model_tag_value"
    ]
    model_tag_value = (
        None
        if len(model_tag_value_param) < 1
        or len(model_tag_name_param[0][1].strip()) == 0
        else model_tag_value_param[0][1]
    )

    return [model_name, model_version, model_tag_name, model_tag_value]


def init():
    """
    Initializer called once per node that runs the scoring job. Parse command
    line arguments and get the right model to use for scoring.
    """
    # global veg_type, save_folder, date_infer, cred, month
    try:

        # model_filter = parse_args()
        # print('tiantian101 - model_filter[0], [1] before I change it', model_filter[0], model_filter[1])
        # model_filter[0] = 'veg_forecasting_model_bs_12mon.pkl'
        # model_filter[1] = 1
        # print('tiantian101 - model_filter[0] after I change it', model_filter[0])
        # amlmodel = get_model(
        #     model_name=model_filter[0],
        #     model_version=model_filter[1],
        #     tag_name=model_filter[2],
        #     tag_value=model_filter[3])     

        # Get parameters
        parser = argparse.ArgumentParser()
        parser.add_argument("--model_name", type=str, dest='model_name', help='input model name')
        parser.add_argument("--model_version", type=int, dest='model_version', help='input model version, if None return latest')
        parser.add_argument("--model_tag_name", type=str, dest='model_tag_name', help='input model tag', default=" ")
        parser.add_argument("--model_tag_value", type=str, dest='model_tag_value', help='input model tag val', default=" ")

        # args = parser.parse_args()
        args, _ = parser.parse_known_args()
        model_name_input = args.model_name
        model_version_input = args.model_version
        model_tag_input = args.model_tag_name
        model_tag_value_input = args.model_tag_value

        amlmodel = get_model(
            model_name=model_name_input, 
            model_version=model_version_input,
            tag_name=model_tag_input,
            tag_value=model_tag_value_input)

        # Load the model using name/version found
        global model
        ## default
        print('tiantian101 - amlmodel.name passed in parallel_batchscore.py now', amlmodel.name)

        modelpath = Model.get_model_path(
            model_name=amlmodel.name, version=amlmodel.version)
        print('tiantian101 - modelpath input now', modelpath)

        # modified

        # print("tiantian102 ---model from os.getenv AZUREML_MODEL_DIR as input", os.getenv("AZUREML_MODEL_DIR").split('/')[-2])
        # modelpath = Model.get_model_path(os.getenv("AZUREML_MODEL_DIR").split('/')[-2], 
        #         version=os.environ.get("MODEL_VERSION"))

        # modelpath = Model.get_model_path(os.getenv('MODEL_NAME'), 
        #         version=os.environ.get("MODEL_VERSION"))

        model = joblib.load(modelpath)
        print("Loaded model {} version {}".format(amlmodel.name,amlmodel.version))
    except Exception as ex:
        print("Error: {}".format(ex))
    
## this has been moved the pre-processing
# def prep_score_data_local(df=None):
#     """Copy from score.py as I cannot load the module. Create veg_forecast dataset ready to be scored.

#     Parameters
#     ----------
#     df : dataframe
#         must be in the exact format from a veg_forecast data pre-processing step.

#     Returns
#     -------
#     data: dataframe
#          with 'infer' columns
         
#     To-Do: 
#         Re-package for multiple month_flt choices. 
#         Enable 12 in month_flt and update Warning msg below.
#     """
#     # run = Run.get_context()

#     df_use = df.copy()
#     # assert df_use.shape[1] == 35
#     assert df_use.shape[0] > 0
#     # run.log_list("colunm names", df_use.columns.to_list())
#     # df_use.dropna(inplace=True)

#     ### Drop unused columns
#     # dropped_names = ['Unnamed: 0', 'lat_4326', 'lon_4326']   # registered dataset changed the 1st col name
#     # Drop first column if it an index column
#     if df_use.columns[0] != "year":
#         print('***** WARNING >>> your input inference file is in the wrong format!!!')
#         # df_use.drop(columns=df_use.columns[0], axis=1, inplace=True)
#     dropped_names = ["lat_4326", "lon_4326"]
#     df_use.drop(columns=dropped_names, axis=1, inplace=True)

#     ### Drop the Year column as it cannot be a feature in forecasting models
#     X = df_use.iloc[:, 1:].values
#     print(f" ******Debug: What is the shape of X:  {X.shape}")
#     # construct a fake array to hold 12 month for OneHotEncoder
#     X_mon = np.zeros((12, X.shape[1]))
#     X_mon[0:12, 0] = np.arange(1,13)
#     X_infer =np.concatenate((X_mon[0:12, :], X))
#     print(f" ******Debug: What is the shape of X_infer before onehot:  {X_infer.shape}")
#     ct = ColumnTransformer(transformers=[('encoder', OneHotEncoder(sparse=False), [0])], remainder='passthrough')
#     X_infer = np.array(ct.fit_transform(X_infer))
#     print(f" ******Debug: What is the shape of X_infer after onehot:  {X_infer.shape}")
#     X_infer_valid = X_infer[12:, :]
#     print(f" ******Debug: What is the shape of X_infer_valid:  {X_infer_valid.shape}")

#     # assert X_infer.shape[1] == 42
#     # data = {"infer": {"X": X_infer[12:, :]}}
#     # run.complete()
#     return X_infer_valid




def run(mini_batch: pd.DataFrame) -> pd.DataFrame:
    """
    The run method is called multiple times by the runtime. Each time
    a mini-batch consisting of a portion of the input data is passed
    in as a pandas DataFrame. The run method should return the scoring
    results as a List or a pandas DataFrame.

    :param mini_batch: Dataframe containing a portion of the scoring data

    :returns: array containing the scores.
    """

    run = Run.get_context()
    # run.log("Debugging--L189: type of input batchdata in run() parallel_batch...py",  type(mini_batch))
    print(f"******Get number of Columns: {len(mini_batch.axes[1])}")
    print(f"################## number of rows {len(mini_batch.index)}")
    

    try:
        result = None

        for _, sample in mini_batch.iterrows():
            # prediction
            # to be modified when adding N first info columns in pre-processing

            pred = model.predict(sample.iloc[4:].values.reshape(1, -1))
            
            # pred = model.predict(sample.values.reshape(1, -1))
            result = (
                np.array(pred) if result is None else np.vstack((result, pred))
            )  # NOQA: E501

        return (
            []
            if result is None
            else mini_batch.join(pd.DataFrame(result, columns=["pred_xmonth"]))
        )

    except Exception as ex:
        print(ex)

