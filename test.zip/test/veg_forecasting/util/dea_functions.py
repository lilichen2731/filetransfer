"""
Author : Catriona Calantzis

These functions were created for the Rio Tinto SpaceTech Project.
For any comments or questions contact Catriona.Calantzis@au.ey.com
"""

import urllib.request, json
import xarray as xr
import odc.aws
import numpy as np
from pyproj import Transformer
from calendar import monthrange
import rasterio
from rasterio.warp import reproject
from rasterio import MemoryFile
from rasterio.profiles import DefaultGTiffProfile
import affine
    
def request_DEA_S2_data(date_range, bbox, bands=None, resolution=10, min_gooddata=0.0, resampling=rasterio.enums.Resampling.nearest, verbose=False):
    """

    Parameters
    ----------
    date_range : tuple of strings, or single string
        The date or date range of the requested data, strings can be formated as YYYY, YYYY-MM, or YYYY-MM-DD
    bbox : list of floats
        The bounding box of the requested data, format [min longitude, min latitude, max longitude, max latitude]
    bands : list of strings
        The requested Sentinel-2 bands e.g. nbart_red, nbart_nir_1. If None, all bands are returned.
         (Default value = None)
    resolution : int
        The resolution in metres of the requested data.
         (Default value = 10)
    min_gooddata : float
        The minimum percentage of 'good' pixels that an image should have in ordered to be returned. Calculated using the fmask band
         (Default value = 0.0)
    resampling : rasterio.enums.Resampling
        The resampling method to use to reproject the data to the new resolution. Only used if resolution is not set to 10.
        See valid options at https://rasterio.readthedocs.io/en/latest/api/rasterio.enums.html#rasterio.enums.Resampling
         (Default value = rasterio.enums.Resampling.nearest)
    verbose : boolean
        Set to True to print out each timestamp as the data is requested, and to see which timestamps did not meet the min_gooddata criteria.
         (Default value = False)

    Returns an xarray Dataset with dimensions time, x, and y.
    -------

    """
    start_date = date_range[0]
    end_date = date_range[1]

    if len(start_date) == 4:
        start_date += '-01-01'
    elif len(start_date) == 7:
        start_date += '-01'

    original_start_date = start_date
    if len(end_date) == 4:
        end_date += '-12-31'
    elif len(end_date) == 7:
        end_date += '-' + str(monthrange(int(end_date[:3]), int(end_date[5:7]))[1])

    root_url = 'https://explorer-aws.dea.ga.gov.au/stac'

    ds = xr.Dataset()
    ds_attrs = {}

    timestamp_count = 0
    good_timestamp_count = 0

    for product in ['s2a_ard_granule', 's2b_ard_granule']:

        start_date = original_start_date

        more_dates_available = True

        while more_dates_available:
            stac_url = f'{root_url}/search?collection={product}&time={start_date}/{end_date}&bbox={str(bbox).replace(" ", "")}'
            with urllib.request.urlopen(stac_url) as url:
                data = json.loads(url.read().decode())

            if bands == None:
                bands = data['features'][0]['assets']

            for i in range(len(data['features'])):

                if i ==0 or data['features'][i]['properties']['datetime'][:10] != data['features'][i-1]['properties']['datetime'][:10]:

                    timestamp_count += 1

                    timestamp = data['features'][i]['properties']['datetime']
                    include_timestamp = True
                    if verbose:
                        print("loading timestamp: ", timestamp)

                    stac_item = data['features'][i]
                    crs = 'EPSG:' + str(data['features'][i]['properties']['proj:epsg'])

                    transformer = Transformer.from_crs("EPSG:4326", crs)
                    min_lat, min_lon = transformer.transform(bbox[1], bbox[0])
                    max_lat, max_lon = transformer.transform(bbox[3], bbox[2])

                    opened = True

                    if min_gooddata > 0.0:
                        url = stac_item['assets']['fmask']['href']
                        bucket, key = odc.aws.s3_url_parse(url)
                        https_url = f'https://dea-public-data.s3.ap-southeast-2.amazonaws.com/{key}'

                        try:
                            da = xr.open_rasterio(https_url)
                            print(opened)
                            mask_lon = (da.y >= min_lon) & (da.y <= max_lon)
                            mask_lat = (da.x >= min_lat) & (da.x <= max_lat)
                            da = da.where(mask_lon & mask_lat, drop=True)

                            if min_gooddata > 1 - ((da == 2) | (da == 3)).astype(int).data.sum() / (da.shape[1] * da.shape[2]):
                                include_timestamp = False
                                if verbose:
                                    print("timestamp {} excluded".format(timestamp))

                        except:
                            print(https_url + " could not be opened. Skipping")
                            opened = False
                    
                    if include_timestamp and opened: 

                        ds_single_timestamp = xr.Dataset()

                        for measurement in bands:
                            url = stac_item['assets'][measurement]['href']
                            bucket, key = odc.aws.s3_url_parse(url)
                            https_url = f'https://dea-public-data.s3.ap-southeast-2.amazonaws.com/{key}'

                            try:
                                da = xr.open_rasterio(https_url)
                                mask_lon = (da.y >= min_lon) & (da.y <= max_lon)
                                mask_lat = (da.x >= min_lat) & (da.x <= max_lat)
                                da = da.where(mask_lon & mask_lat, drop=True)

                                if da.attrs['crs'].startswith("+init="):
                                    da.attrs['crs'] = da.attrs['crs'][6:]

                                if abs(int(da.attrs['res'][0])) != resolution:
                                    aligned_target = rasterio.warp.aligned_target(affine.Affine(da.attrs['transform'][0], da.attrs['transform'][1], da.attrs['transform'][2], 
                                                                da.attrs['transform'][3], da.attrs['transform'][4], da.attrs['transform'][5]), len(da['x']), len(da['y']), resolution)

                                    new_transform = affine.Affine(resolution, da.attrs['transform'][1], da.attrs['transform'][2], 
                                                                    da.attrs['transform'][3], -resolution, da.attrs['transform'][5])

                                    reprojected_da = np.full((aligned_target[1], aligned_target[2]), fill_value=None, dtype='float64')

                                    src_crs = {'init': da.attrs['crs']}

                                    reprojected_da = np.array([reproject(da, reprojected_da,
                                                                dst_nodata=None,
                                                                src_transform=da.attrs['transform'],
                                                                dst_transform=new_transform,
                                                                src_crs=src_crs,
                                                                dst_crs=da.attrs['crs'],
                                                                resampling=resampling)[0]])

                                    profile = DefaultGTiffProfile(res=resolution,
                                                                transform=new_transform,
                                                                dtype=reprojected_da.dtype.name,
                                                                count=1,
                                                                height=reprojected_da.shape[1],
                                                                width=reprojected_da.shape[2])

                                    with MemoryFile() as memfile:
                                        with memfile.open(**profile) as dataset:
                                            dataset.write(reprojected_da)
                                        with memfile.open() as dataset:
                                            da=xr.open_rasterio(dataset)     

                                new_ds = xr.Dataset(
                                    data_vars = {measurement: (("time", "y", "x"), da.data)},
                                    coords=dict(
                                        time=[timestamp],
                                        y=(["y"], da.coords['y'].data ),
                                        x=(["x"], da.coords['x'].data )
                                    )
                                )
                                
                                ds_attrs = da.attrs

                                ds_single_timestamp = ds_single_timestamp.merge(new_ds)
                                
                            except:
                                print(https_url + " could not be opened. Skipping")   

                        ds = ds.merge(ds_single_timestamp)
                        good_timestamp_count += 1  

            if len(data['features']) < 20:
                more_dates_available = False
            else:
                start_date = data['features'][19]['properties']['datetime'][:10]

    ds.attrs = ds_attrs

    print("{} timestamps loaded from {} timestamps".format(good_timestamp_count, timestamp_count))

    return ds

def request_DEA_fc_data(year_range, bbox, bands=None, resolution=25, resampling=rasterio.enums.Resampling.nearest, verbose=False):
    """

    Parameters
    ----------
    year_range : tuple of strings, or single string
        The year or year range of the requested data, strings must formated as YYYY
    bbox : list of floats
        The bounding box of the requested data, format [min longitude, min latitude, max longitude, max latitude]
    bands : list of strings
        The requested Sentinel-2 bands e.g. nbart_red, nbart_nir_1. If None, all bands are returned.
         (Default value = None)
    resolution : int
        The resolution in metres of the requested data.
         (Default value = 25)
    resampling : rasterio.enums.Resampling
        The resampling method to use to reproject the data to the new resolution. Only used if resolution is not set to 25.
        See valid options at https://rasterio.readthedocs.io/en/latest/api/rasterio.enums.html#rasterio.enums.Resampling
         (Default value = rasterio.enums.Resampling.nearest)
    verbose : boolean
        Set to True to print out each timestamp as the data is requested.
         (Default value = False)

    Returns an xarray Dataset with dimensions time, x, and y.
    -------

    """
    
    if type(year_range) == str:
        year_range = (year_range, year_range)
    start_date = year_range[0]
    end_date = year_range[1]

    if len(start_date) == 4:
        start_date += '-01-01'
    elif len(start_date) == 7:
        start_date += '-01'

    original_start_date = start_date
    if len(end_date) == 4:
        end_date += '-12-31'
    elif len(end_date) == 7:
        end_date += '-' + str(monthrange(int(end_date[:3]), int(end_date[5:7]))[1])

    print(start_date, end_date)

    root_url = 'https://explorer-aws.dea.ga.gov.au/stac'

    ds = xr.Dataset()

    product = 'fc_percentile_albers_annual'

    more_dates_available = True

    ds_attrs = {}

    timestamp_count = 0

    while more_dates_available:
        stac_url = f'{root_url}/search?collection={product}&time={start_date}/{end_date}&bbox={str(bbox).replace(" ", "")}'
        with urllib.request.urlopen(stac_url) as url:
            data = json.loads(url.read().decode())

        if bands == None:
            bands = data['features'][0]['assets']

        for i in range(len(data['features'])):

            if i ==0 or data['features'][i]['properties']['datetime'][:10] != data['features'][i-1]['properties']['datetime'][:10]:

                timestamp_count += 1

                timestamp = data['features'][i]['properties']['datetime']
                if verbose:
                    print("loading timestamp: ", timestamp)

                stac_item = data['features'][i]
                
                ds_single_timestamp = xr.Dataset()

                for measurement in bands:
                    url = stac_item['assets'][measurement]['href']
                    bucket, key = odc.aws.s3_url_parse(url)
                    https_url = f'https://dea-public-data.s3.ap-southeast-2.amazonaws.com/{key}'

                    da = xr.open_rasterio(https_url)
                    if da.attrs['crs'].startswith("+init="):
                        da.attrs['crs'] = da.attrs['crs'][6:]
                    ds_attrs = da.attrs

                    transformer = Transformer.from_crs("EPSG:4326", da.attrs['crs'])
                    min_lat, min_lon = transformer.transform(bbox[1], bbox[0])
                    max_lat, max_lon = transformer.transform(bbox[3], bbox[2])
                    mask_lon = (da.y >= min_lon) & (da.y <= max_lon)
                    mask_lat = (da.x >= min_lat) & (da.x <= max_lat)
                    da = da.where(mask_lon & mask_lat, drop=True)

                    ds_single_timestamp = xr.Dataset()

                    if da.attrs['crs'].startswith("+init="):
                        da.attrs['crs'] = da.attrs['crs'][6:]

                    if abs(int(da.attrs['res'][0])) != resolution:
                        aligned_target = rasterio.warp.aligned_target(affine.Affine(da.attrs['transform'][0], da.attrs['transform'][1], da.attrs['transform'][2], 
                                                    da.attrs['transform'][3], da.attrs['transform'][4], da.attrs['transform'][5]), len(da['x']), len(da['y']), resolution)

                        new_transform = affine.Affine(resolution, da.attrs['transform'][1], da.attrs['transform'][2], 
                                                                da.attrs['transform'][3], -resolution, da.attrs['transform'][5])

                        reprojected_da = np.full((aligned_target[1], aligned_target[2]), fill_value=None, dtype='float64')

                        src_crs = {'init': da.attrs['crs']}

                        reprojected_da = np.array([reproject(da, reprojected_da,
                                                            dst_nodata=None,
                                                            src_transform=da.attrs['transform'],
                                                            dst_transform=new_transform,
                                                            src_crs=src_crs,
                                                            dst_crs=da.attrs['crs'],
                                                            resampling=resampling)[0]])

                        profile = DefaultGTiffProfile(res=resolution,
                                                    transform=new_transform,
                                                    dtype=reprojected_da.dtype.name,
                                                    count=1,
                                                    height=reprojected_da.shape[1],
                                                    width=reprojected_da.shape[2])

                        with MemoryFile() as memfile:
                            with memfile.open(**profile) as dataset:
                                dataset.write(reprojected_da)
                            with memfile.open() as dataset:
                                da=xr.open_rasterio(dataset)      

                    new_ds = xr.Dataset(
                        data_vars = {measurement: (("time", "y", "x"), da.data)},
                        coords=dict(
                            time=[timestamp],
                            y=(["y"], da.coords['y'].data),
                            x=(["x"], da.coords['x'].data)
                        )
                    )

                    ds_attrs = da.attrs

                    ds_single_timestamp = ds_single_timestamp.merge(new_ds)

                ds = ds.merge(ds_single_timestamp)

        if len(data['features']) < 20:
            more_dates_available = False
        else:
            start_date = data['features'][19]['properties']['datetime'][:10]

    ds.attrs = ds_attrs

    print("{} timestamps loaded".format(timestamp_count))

    return ds