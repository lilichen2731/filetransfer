from fsspec.implementations.http import HTTPFileSystem
from vdsm_util import get_blob_client, get_blobnames
import xarray as xr
import datetime
from dateutil.relativedelta import relativedelta
import pickle
from azureml.core.run import Run
import traceback
import pandas as pd
import argparse
import sys

def merge_in_time_S2(region_name, start_month='2015-11', end_month='2021-10', write_to_blob=True, conn_str=None):

    ds_all = xr.Dataset()

    start_date = datetime.date(int(start_month[:4]), int(start_month[5:]), 1)
    end_date = datetime.date(int(end_month[:4]), int(end_month[5:]), 1) + relativedelta(months=1)

    months = []
    month_dt = start_date
    while month_dt < end_date:
        months.append(str(month_dt)[:7])
        month_dt = month_dt + relativedelta(months=1)

    print(months)
    print(region_name)

    for month in months:

        print(month)

        try:
            fn = month[:4] + '/' + month[5:7] + '/staging/' + region_name + '_S2.pkl'
            blob_client = get_blob_client(filename=fn, conn_str=conn_str)
            if blob_client.get_blob_properties().size > 20000:
                unpickled_ds = pickle.loads(blob_client.download_blob().content_as_bytes())
                try:
                    checklen = len(unpickled_ds.time)
                except:
                    checklen = 0
                if checklen > 0:
                    ds_all = ds_all.merge(unpickled_ds)

        except:
            print(traceback.format_exc())


    if write_to_blob:
        filename = 'training/merged/' + region_name + '_' + start_month + '_' + end_month + '.pkl'
        pickled_ds = pickle.dumps(ds_all)
        blob_client = get_blob_client(filename=filename, conn_str=conn_str)
        blob_client.upload_blob(pickled_ds, overwrite=True)
        return filename

    return ds_all

def run(df = None):

    run = Run.get_context()
    conn_str = run.get_secret("asartpacedevstvdsm001-connstr")

    print(sys.version)
    
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--start_month",
        type=str,
        dest='start_month'
    )
    parser.add_argument(
        "--end_month",
        type=str,
        dest='end_month'
    )
    args, _ = parser.parse_known_args()
    start_month = args.start_month
    end_month = args.end_month

    filename_df = pd.DataFrame(columns=['filename'])

    for index, row in df.iterrows():

        if len(get_blobnames('training/merged/' + row['name'] + '_' + start_month + '_' + end_month + '.pkl', conn_str=conn_str)) > 0:
            print('exists')
            continue

        filename_df.append({'filename' : merge_in_time_S2(row['name'], start_month = start_month, end_month = end_month, conn_str=conn_str)}, ignore_index=True)

    return filename_df