from azureml.core.run import Run
from azureml.core import Dataset, Datastore, Workspace
from azureml.core.runconfig import RunConfiguration
from azureml.core import Environment, Experiment
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.datadrift import DataDriftDetector
# from datetime import datetime
from dateutil.relativedelta import relativedelta
from io import StringIO
import datetime
import calendar
import argparse
import pandas as pd
from azureml.core import Workspace
from azure.storage.blob import BlobClient, BlobServiceClient, ContainerClient, __version__
import pandas as pd

run = Run.get_context()
ws = run.experiment.workspace
conn_str = run.get_secret("asartpacedevstvdsm001-connstr")

parser = argparse.ArgumentParser()

parser.add_argument(
    "--veg_type",
    type=str,
    dest='veg_type'
)

parser.add_argument(
    "--end_month",
    type=str,
    dest='end_month'
)

args, _ = parser.parse_known_args()
veg_type = args.veg_type
end_month = args.end_month

# create_target_dataset(end_month=end_month, veg_type=veg_type, conn_str=conn_str, write_to_blob=True)

blob_client = BlobServiceClient.from_connection_string(conn_str)
container_client = blob_client.get_container_client("data")

end_month_dt = datetime.date(int(end_month[:4]), int(end_month[5:]), 1)
start_month_dt = datetime.date(int(end_month[:4]), int(end_month[5:]), 1) + relativedelta(months=-12)

months = []
month_dt = start_month_dt
while month_dt < end_month_dt:
    month_dt = month_dt + relativedelta(months=1)
    months.append(str(month_dt)[:7])

target_df = pd.DataFrame()

for month in months:

    blob_names = container_client.list_blobs(name_starts_with=f'{month[:4]}/{month[5:]}/fused/{veg_type}_v1')

    for blob_name in blob_names:
        blob_service_client = BlobServiceClient.from_connection_string(conn_str)
        blob_client = blob_service_client.get_blob_client(container='data', blob=blob_name)
        # blob_client = get_blob_client(filename=blob_name, conn_str=conn_str)
        df = pd.read_csv(StringIO(blob_client.download_blob().content_as_text()))
        if datetime.date(int(end_month[:4]), int(end_month[5:]), 1) >= datetime.date(2021, 12, 1):
            try:
                df = df.sample(n=100)
            except:
                pass
        target_df = target_df.append(df)

target_df.drop(columns=['filename', 'lat', 'lon'], inplace=True)
target_df.insert(1, 'month', target_df.iloc[:, 1:13].values.argmax(axis=1) + 1)
target_df.drop(columns=['month1','month2','month3','month4','month5','month6','month7','month8','month9','month10','month11','month12'], inplace=True)

fn = f'data_drift/target/{end_month}/{veg_type}.csv'
output = target_df.to_csv(index=False, encoding='utf-8', header=True)
# blob_client = get_blob_client(filename=fn, conn_str=conn_str)
blob_service_client = BlobServiceClient.from_connection_string(conn_str)
blob_client = blob_service_client.get_blob_client(container='data', blob=fn)
blob_client.upload_blob(output, overwrite=True, blob_type='BlockBlob')

# register dataset from datastore
blob_datastore = Datastore.get(ws, datastore_name = "vdsmtrain")

# create a TabularDataset from file in datastore
blob_path = "data_drift/target/*/" +  veg_type + ".csv"
partition_format = 'data_drift/target/{ymd-drift:yyyy-MM}/'  + veg_type +'.csv'

datastore_paths = [(blob_datastore, blob_path)]
target_data_set = Dataset.Tabular.from_delimited_files(path=datastore_paths, partition_format=partition_format)

# assign the timestamp attribute to a real or virtual column in the dataset
target_data = target_data_set.with_timestamp_columns('ymd-drift')

# extract the ymd-drift
ymd_drift_col = target_data.to_pandas_dataframe()['ymd-drift']
yyyy_min_drift = min(ymd_drift_col).year
mm_min_drift = min(ymd_drift_col).month
yyyy_max_drift = max(ymd_drift_col).year
mm_max_drift = max(ymd_drift_col).month

# register the dataset as the target dataset
registered_data_name = 'monthly drift_target_' + veg_type
target_dataset = target_data.register(workspace=ws, 
                           name=registered_data_name,
                           description='monthly drift target for ' + veg_type,
                           tags = {'format':'CSV', 'veg_type':veg_type},
                           create_new_version=True)



# set up data drift detector
data_drift_name = veg_type + '-mdrift-' 

# get data drift detector by name
monitor = DataDriftDetector.get_by_name(ws, data_drift_name)

backfill1 = monitor.backfill(datetime.datetime(yyyy_min_drift, mm_min_drift, 1), datetime.datetime(yyyy_max_drift, mm_max_drift, 1))
backfill1
