import requests
from azureml.core.authentication import MsiAuthentication
from azureml.core.run import Run
import argparse

run = Run.get_context()
parser = argparse.ArgumentParser()

parser.add_argument(
    "--month",
    type=str,
    dest='month'
)

args, _ = parser.parse_known_args()
month = args.month

msi_auth = MsiAuthentication(identity_config = {"client_id" : 'db8e6c50-4a0f-4e53-861d-fd2d6828e0d5'})
auth_header = msi_auth.get_authentication_header()
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-spacetech/providers/Microsoft.MachineLearningServices/workspaces/aml-ws-spacetech001/PipelineRuns/PipelineSubmit/978fdd72-3eb3-4ca4-bc5e-2f2413a37524'

response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "infer_fusion", "ParameterAssignments": {"month": month, "random_n": -1, "pv": "True", "npv": "False"}})
run.log('response1', response.status_code)

response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "infer_fusion", "ParameterAssignments": {"month": month, "random_n": -1, "pv": 'False', "npv": 'True'}})
run.log('response2', response.status_code)

response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "infer_fusion", "ParameterAssignments": {"month": month, "random_n": -1, "pv": 'False', "npv": 'False'}})
run.log('response3', response.status_code)

rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/eab31881-bae5-4619-b4c5-b9374d1ec466'

response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger_inference"})
run.log('response4', response.status_code)

rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-spacetech/providers/Microsoft.MachineLearningServices/workspaces/aml-ws-spacetech001/PipelineRuns/PipelineSubmit/af303441-6626-4661-8b42-849d1b426061'

response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "data_drift", "ParameterAssignments": {"veg_type": "pv", "end_month": month}})
run.log('response5', response.status_code)

response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "data_drift", "ParameterAssignments": {"veg_type": "npv", "end_month": month}})
run.log('response6', response.status_code)

response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "data_drift", "ParameterAssignments": {"veg_type": "bs", "end_month": month}})
run.log('response7', response.status_code)