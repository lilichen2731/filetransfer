import requests
from azureml.core.authentication import MsiAuthentication
from azureml.core.run import Run

msi_auth = MsiAuthentication(identity_config = {"client_id" : 'db8e6c50-4a0f-4e53-861d-fd2d6828e0d5'})
auth_header = msi_auth.get_authentication_header()
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/eab31881-bae5-4619-b4c5-b9374d1ec466'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger_inference"})

run = Run.get_context()
run.log('response', response.status_code)