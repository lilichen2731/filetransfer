"""Custom functions used in the VDSM data fusion steps.
"""
from fsspec.implementations.http import HTTPFileSystem
from django.http import HttpResponse
from azure.storage.blob import BlobClient, BlobServiceClient, ContainerClient, __version__
from azure.storage.blob import generate_blob_sas, AccountSasPermissions
from datetime import timedelta
from dateutil.relativedelta import relativedelta
import datetime
import json
import os
import sys
import affine
import pandas as pd
import math
import time
import geopandas as gpd
from pyproj import Transformer
import pickle as pkl
import numpy as np
import rasterio
from rasterio.features import rasterize
import xarray as xr
from functools import wraps
from azureml.core.authentication import MsiAuthentication
from azureml.core import Workspace

account_details = {"account_name": "asartpacedevstvdsm001", "container_name": "data"}

def get_blob_client(filename:str, conn_str=None, account_details=account_details):
    """ Purpose: initiate a client for writing into a blob location.
        Parameters:
        --------
        filename: string, 
                out_put filename to write to a blob.
    """
    blob_service_client = BlobServiceClient.from_connection_string(conn_str)
    blob_client = blob_service_client.get_blob_client(container=account_details["container_name"], blob=filename)
    return blob_client

def get_blobnames(search_dir='./', conn_str=None, account_details=account_details):
    """ Purpose: list all files under the search directory of a  blob location.
        Parameters:
        --------
        search_dir: str, optional
             searching directory on the blob. 
             Default is odc_vm_data for this VM created by admin acc.
        Return:
             A blob container service
        Examples:
        ### Test deleting files from blob
                blob_cont = get_blobnames()
                file_del = '.require_vmcopy.txt'
                try:
                     blob_cont.delete_blob(file_del)
                except:
                    print('no such file')   
                       
    """
    blob_service_client = BlobServiceClient.from_connection_string(conn_str)
    container_client = blob_service_client.get_container_client(account_details["container_name"])
    blob_list = container_client.list_blobs()
    return_list = []
    for blob in blob_list:
        # list all files under the blob directory 'odc_vm_data'
        if search_dir in blob.name:
            return_list.append(blob.name)
            # print(blob.name)

    return return_list

def get_blobservice(url_token_sas=None, conn_str=None):
    """ Alternative ways to create a blob service
    """
    try:
        bs = BlobServiceClient.from_connection_string(conn_str)
        return bs
    except:
        try:
            import traceback
        
            return HttpResponse(traceback.format_exc() + str(os.environ.keys()))
        except:
            import traceback
            return HttpResponse(traceback.format_exc())

def mean_value_one_var(ds, var, min_val=-1.5, max_val=1.5):
    """ Purpose: obtain the mean value of a band 'var' from an xarray.Dataset, exlcuding outliers and nan/inf values
        Parameters: 
        --------
        ds: xarray.Dataset, 
        var: string,
            a band contained in ds
        min_val: any numerical type,
            the minimum acceptable value for var
        max_val: any numerical type,
            the maximum acceptable value for var
        
        I have set min_val and max_val to -1.5 and 1.5 as default because so far I only use this function for EVI (CC)
    """
    ### TT-todo: the code below can be faster by making use of list comp. or np.array
    evi_vals = []
    time_index = 0
    for time in ds.time.data:
        evi_val = ds.isel(time=time_index)['evi'].data[0][0]
        if evi_val <= max_val and evi_val >= min_val:
            evi_vals.append(evi_val)
        time_index += 1

    return np.nanmean(np.array(evi_vals))

def mean_value_dvar(ds, var='evi', min_val=-1.5, max_val=1.5):
    """ Purpose: obtain the mean value of a band 'var' from an xarray.Dataset, exlcuding outliers and nan/inf values
        Parameters: 
        --------
        ds: xarray.Dataset, 
        var: string,
            a band contained in ds
        min_val: any numerical type,
            the minimum acceptable value for var
        max_val: any numerical type,
            the maximum acceptable value for var
        
        I have set min_val and max_val to -1.5 and 1.5 as default because so far I only use this function for EVI (CC)
    """
    evi_vals = []

    try:
        checklen = len(ds.time.data)
    except:
        checklen = ds.time.data.size

    if isinstance(checklen, int) and checklen == 0:
        result = np.NaN
    if isinstance(checklen, int) and checklen == 1:
        result = ds[var].data.flatten()
    if isinstance(checklen, int) and checklen >= 2:
        time_index = 0
        for time in ds.time.data:
            evi_val = ds.isel(time=time_index)[var].data
            if evi_val <= max_val and evi_val >= min_val:
                evi_vals.append(evi_val)
            time_index += 1
        result = np.nanmean(np.array(evi_vals))
    if isinstance(checklen, tuple) and checklen[0] == 0:  
        result = np.NaN
    if isinstance(result, np.ndarray) or isinstance(result, list):
        result = result[0]
    if result > 1.5:
        result = 1.5
    if result < -1.5:
        result = -1.5
    return result


def get_previous_month_string(month_year):
    """ Purpose: return a string representing the previous month
        Parameters: 
        --------
        request: string,
                 expected format YYYY-MM
        e.g. 2017-01 will return 2016-12
    """
    for p in pd.period_range(month_year, month_year, freq='M')-1:
        return str(p)
    
def find_time_index(request, ds):
    """ Purpose: find a time index in the dataset ds which match the request
        Parameters: 
        --------
        request: string,
                 expected format YYYY-MM-DD or YYYY-MM
                 YYYY-MM will cause the function to return the first time index from the requested month
        ds: xarray.Dataset with a time dimension
        ### TT-todo: the code below can be faster by making use of Dataset.where() 
    """
    if len(request) == 7 or len(request) == 10:
        if type(ds['time'].data[0]) == np.datetime64:
            for i, s in enumerate(list(np.datetime_as_string(ds['time'].data))):
                if request in s:
                    return i
        if type(ds['time'].data[0]) == str:
            for i, s in enumerate(ds['time'].data):
                if request in s:
                    return i
            
def find_all_month_indices(request, ds):
    ### TT-todo: the code below can be faster by making use of Dataset.where() and/or list comp.
    if len(request)==7:
        indices = []
        for i, s in enumerate(list(np.datetime_as_string(ds['time'].data))):
            if request in s:
                indices.append(i)
        return indices
    
def find_all_year_indices(request, ds):
    ### TT-todo: the code below can be faster by making use of Dataset.where() and/or list comp.
    if len(request)==4:
        indices = []
        for i, s in enumerate(list(np.datetime_as_string(ds['time'].data))):
            if request in s:
                indices.append(i)
        return indices

def bilinear_interpolation(x, y, points):
    '''Interpolate (x,y) from values associated with four points.

    The four points are a list of four triplets:  (x, y, value).
    The four points can be in any order.  They should form a rectangle.

        >>> bilinear_interpolation(12, 5.5,
        ...                        [(10, 4, 100),
        ...                         (20, 4, 200),
        ...                         (10, 6, 150),
        ...                         (20, 6, 300)])
        165.0

    '''
    # Got this from https://stackoverflow.com/questions/8661537/how-to-perform-bilinear-interpolation-in-python :D

    points = sorted(points)               # order points by x, then by y
    (x1, y1, q11), (_x1, y2, q12), (x2, _y1, q21), (_x2, _y2, q22) = points

    return (q11 * (x2 - x) * (y2 - y) +
            q21 * (x - x1) * (y2 - y) +
            q12 * (x2 - x) * (y - y1) +
            q22 * (x - x1) * (y - y1)
           ) / ((x2 - x1) * (y2 - y1) + 0.0)

def interpolate_single_band(ds_env, lat, lon, band, date, crs="EPSG:3577"):
    """ Purpose: interpolate a single value for a single band at the specified latitude and longitude
        Parameters: 
        --------
        ds_env: xarray.Dataset
        lat: float, representing latitude in the specified crs
        lon: float, representing longitude in the specified crs
        band: string, representing a band in the ds_env dataset
        date: string, in the format YYYY-MM 
        crs: string, representing the crs of the lat and lon values
    """
    
    transformer = Transformer.from_crs(crs, "EPSG:4326")
    s2_lat, s2_lon = transformer.transform(lon, lat)
    
    time_index = find_time_index(date, ds_env)

    min_lat = math.floor(s2_lat*10)/10
    max_lat = math.ceil(s2_lat*10)/10
    min_lon = math.floor(s2_lon*10)/10
    max_lon = math.ceil(s2_lon*10)/10

    filt1 = ds_env['latitude'] == min_lat
    filt2 = ds_env['latitude'] == max_lat
    filt3 = ds_env['longitude'] == min_lon
    filt4 = ds_env['longitude'] == max_lon

    min_lat_index = list(filt1.data).index(True)
    max_lat_index = list(filt2.data).index(True)
    min_lon_index = list(filt3.data).index(True)
    max_lon_index = list(filt4.data).index(True)

    points = ((min_lat, min_lon, ds_env.isel(time=time_index)[band].data[min_lat_index][min_lon_index]),
              (max_lat, min_lon, ds_env.isel(time=time_index)[band].data[max_lat_index][min_lon_index]),
              (min_lat, max_lon, ds_env.isel(time=time_index)[band].data[min_lat_index][max_lon_index]),
              (max_lat, max_lon, ds_env.isel(time=time_index)[band].data[max_lat_index][max_lon_index]))

    interpolated_value = bilinear_interpolation(s2_lat, s2_lon, points)

    if math.isnan(interpolated_value):
        interpolated_value = np.nanmean([ds_env.isel(time=time_index)[band].data[min_lat_index][min_lon_index],
                                         ds_env.isel(time=time_index)[band].data[max_lat_index][min_lon_index],
                                         ds_env.isel(time=time_index)[band].data[min_lat_index][max_lon_index],
                                         ds_env.isel(time=time_index)[band].data[max_lat_index][max_lon_index]])

    return interpolated_value

    # return bilinear_interpolation(s2_lat, s2_lon, points)


def locate_index(ds_fc, lat_pv, lon_pv, itime=28, var_s='PV_PC_90'):
    """
    Purpose: return the index for a given value set in lat and lon
    Input para: 
             ds_fc: xarray dataset
             lat_pv, lon_pv: coordinates, floats in EPSG:4326
     Optional para:  itime=28, time index, 
                        var_s='PV_PC_90', a variable name for getting Xarray Dataset
    Return:  ix, iy, itime = index in x, y, time, 
             x, y, time, =  matched values
    """
    transformer = Transformer.from_crs("EPSG:4326", "EPSG:3577")
    # Note the order of the output
    s_lon_3577, s_lat_3577 = transformer.transform(lat_pv, lon_pv)  ## .transformat(lat/y, lon/x)
    # value for the time index
    time_pv = ds_fc.coords['time'][itime].data
    ds_pv_sel = ds_fc[var_s].sel(x=s_lon_3577, y=s_lat_3577, time=time_pv, method='nearest')
    filt1 =  ds_fc[var_s].x == ds_pv_sel.x.data
    ix = list(filt1.data).index(True)
    filt2 =  ds_fc[var_s].y == ds_pv_sel.y.data
    iy = list(filt2.data).index(True)
    return ix, iy, itime, ds_pv_sel.x.data, ds_pv_sel.y.data, time_pv


def get_mask_sh(ds, gdf):
    ## CC to add exception handling here
    try:
        crs = ds.crs
    except:
        crs = "epsg:3577"
    transform=affine.Affine(10.0, 0.0, ds.coords['x'].data.min()-5,
                        0.0, -10.0, ds.coords['y'].data.max()+5)
    y, x = len(ds.coords['y']), len(ds.coords['x'])
    try:
        gdf_reproj = gdf.to_crs(crs=crs)
    except:
        # Sometimes the crs can be a datacube utils CRS object
        # so convert to string before reprojecting
        gdf_reproj = gdf.to_crs(crs=str(crs))
    # Use geometry directly (will produce a boolean numpy array)
    shapes = gdf_reproj.geometry
    # Rasterise shapes into an array
    arr = rasterize(shapes=shapes,
                    out_shape=(y, x),
                    transform=transform)
    # Convert result to a xarray.DataArray
    xarr = xr.DataArray(arr,
                        coords=(ds.coords['y'], ds.coords['x']),
                        dims=('y', 'x'),
                        attrs=ds.attrs)
    return xarr

def fill_missing_months_CO2(co2_df, month):
    latest_month = str(co2_df.index[-1])[:7]
    end_month_dt = datetime.date(int(month[:4]), int(month[5:]), 1)
    latest_month_dt = datetime.date(int(latest_month[:4]), int(latest_month[5:]), 1)

    months = []
    month_dt = latest_month_dt
    while month_dt < end_month_dt:
        month_dt = month_dt + relativedelta(months=1)
        months.append(str(month_dt)[:7])

    for missing_month in months:
        co2_df = co2_df.append(pd.DataFrame(index = [missing_month], columns = ['average'], data = [co2_df.iloc[-1]]))

    return co2_df

def fill_missing_months_climate(ds_env, month):
    latest_month = str(ds_env.time.data[-1])[:7]
    end_month_dt = datetime.date(int(month[:4]), int(month[5:]), 1)
    latest_month_dt = datetime.date(int(latest_month[:4]), int(latest_month[5:]), 1)

    months = []
    month_dt = latest_month_dt
    while month_dt < end_month_dt:
        month_dt = month_dt + relativedelta(months=1)
        months.append(str(month_dt)[:7])

    for missing_month in months:
        ds_env_one_month = ds_env.sel(time=ds_env.time.data[-1])
        ds_env_one_month.time.data = np.array(missing_month + '-01T00:00:00.000000000', dtype='datetime64[ns]')
        ds_env = xr.concat([ds_env, ds_env_one_month], dim='time')

    return ds_env

def create_target_dataset(end_month, veg_type='pv', conn_str=None, write_to_blob=True):

    blob_client = BlobServiceClient.from_connection_string(conn_str)
    container_client = blob_client.get_container_client("data")

    end_month_dt = datetime.date(int(end_month[:4]), int(end_month[5:]), 1)
    start_month_dt = datetime.date(int(end_month[:4]), int(end_month[5:]), 1) + relativedelta(months=-12)

    months = []
    month_dt = start_month_dt
    while month_dt < end_month_dt:
        month_dt = month_dt + relativedelta(months=1)
        months.append(str(month_dt)[:7])

    target_df = pd.DataFrame()

    for month in months:

        blob_names = container_client.list_blobs(name_starts_with=f'{month[:4]}/{month[5:]}/fused/{veg_type}_v1')

        for blob_name in blob_names:
            blob_client = get_blob_client(filename=blob_name, conn_str=conn_str)
            df = pd.read_csv(StringIO(blob_client.download_blob().content_as_text()))
            if datetime.date(int(end_month[:4]), int(end_month[5:]), 1) >= datetime.date(2021, 12, 1):
                try:
                    df = df.sample(n=100)
                except:
                    pass
            target_df = target_df.append(df)

    target_df.drop(columns=['filename', 'lat', 'lon'], inplace=True)
    target_df.insert(1, 'month', target_df.iloc[:, 1:13].values.argmax(axis=1) + 1)
    target_df.drop(columns=['month1','month2','month3','month4','month5','month6','month7','month8','month9','month10','month11','month12'], inplace=True)

    if write_to_blob:
        fn = f'data_drift/target/{end_month}/{veg_type}.csv'
        output = target_df.to_csv(index=False, encoding='utf-8', header=True)
        blob_client = get_blob_client(filename=fn, conn_str=conn_str)
        blob_client.upload_blob(output, overwrite=True, blob_type='BlockBlob')
        return fn

    return target_df
