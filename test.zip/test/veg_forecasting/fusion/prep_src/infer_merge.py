from fsspec.implementations.http import HTTPFileSystem
from vdsm_util import get_blob_client
import xarray as xr
import datetime
from dateutil.relativedelta import relativedelta
import pickle
from azureml.core.run import Run
import traceback
import pandas as pd
import argparse
# from vdsm_logger.logger import Logger

def merge_in_time_S2(region_name, start_month, end_month, write_to_blob=True, conn_str=None):

    ds_all = xr.Dataset()

    start_date = datetime.date(int(start_month[:4]), int(start_month[5:]), 1)
    end_date = datetime.date(int(end_month[:4]), int(end_month[5:]), 1) + relativedelta(months=1)

    months = []
    month_dt = start_date
    while month_dt < end_date:
        months.append(str(month_dt)[:7])
        month_dt = month_dt + relativedelta(months=1)

    for month in months:

        try:
            fn = month[:4] + '/' + month[5:7] + '/staging/' + region_name + '_S2.pkl'
            blob_client = get_blob_client(filename=fn, conn_str=conn_str)
            unpickled_ds = pickle.loads(blob_client.download_blob().content_as_bytes())
            ds_all = ds_all.merge(unpickled_ds)

        except:
            print(traceback.format_exc())

    if write_to_blob:
        filename = month[:4] + '/' + month[5:7] + '/merged/' + region_name + '_S2_' + start_month + '_' + end_month + '.pkl'
        pickled_ds = pickle.dumps(ds_all)
        blob_client = get_blob_client(filename=filename, conn_str=conn_str)
        blob_client.upload_blob(pickled_ds, overwrite=True)
        return filename

    return ds_all

def merge_in_time_fc(region_name, start_year, end_year, write_to_blob=True):

    ds_all = xr.Dataset()

    for year in range(int(start_year), int(end_year)+1):

        fn = str(year) + '/staging/' + region_name + '_fc.pkl'
        fn_url = create_blob_stream(fn, t_expire=1)
        fs = HTTPFileSystem()
        
        with fs.open(fn_url) as f:
            unpickled_ds = pickle.load(f)
            ds_all = ds_all.merge(unpickled_ds)
    
    if write_to_blob:
        filename = region_name + '_fc_' + start_year + '_' + end_year + '.pkl'
        pickled_ds = pickle.dumps(ds_all)
        blob_client = write_blob_client(filename, 'tmp/')
        blob_client.upload_blob(pickled_ds, overwrite=True)
        return filename

    return ds_all

def run(df = None):

    run = Run.get_context()
    conn_str = run.get_secret("asartpacedevstvdsm001-connstr")
    # conn_str = "Server=tcp:asqlservernew.database.windows.net,1433;Initial Catalog=asqldbnew;Persist Security Info=False;User ID=CloudSA020222wen;Password=NewSA02022TTcat;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"

    # logger = Logger(job_id=2, run_id=run_id, conn_str=conn_str)
    # logger.run(description="Starting", date_time=datetime.datetime.now())

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--month",
        type=str,
        dest='month'
    )
    args, _ = parser.parse_known_args()
    end_month = args.month
    start_month = str(int(end_month[:4])-1) + '-' + args.month[-2:]

    filename_df = pd.DataFrame(columns=['filename'])

    for index, row in df.iterrows():
        filename_df.append({'filename' : merge_in_time_S2(row['name'], start_month = start_month, end_month = end_month, conn_str=conn_str)}, ignore_index=True)

    return filename_df