import argparse
from azureml.core.run import Run
from azureml.core import Dataset, Datastore, Workspace
from azureml.core.runconfig import RunConfiguration
from azureml.core import Environment, Experiment
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException

def register_training_dataset(ds_str:str, veg_type:str, train_datastore_name='vdsmtrain',
                             ds_register_name=None, ws=None):
    """Register training datasets after data fusion step.
    Input param ds_str: string for path of the training data folder 
    Input param veg_type: string for veg_type, choices 'pv', 'npv', 'bs'
    
    Optional param training_datastore_name:, str, default = 'vdsmtrain'
            if not exist, will register with our custom blob using keyvault
    Optional param ds_register_name: dataset register name, default is 'training_'+veg_type+'_folder'
    Optional param ws:  AML workspace, if not specified, will get from default config
   
    Example:
        veg_type = 'pv'
        ds_str = f'traininginput_{veg_type}_v2/**'
        register_training_dataset(ds_str, veg_type)
    """
    run = Run.get_context()

    if ds_str is None:
        ds_str = 'traininginput_pv_v0/**'


    if ws is None:
       ws = Workspace.from_config()

    if ds_register_name is None:
       ds_register_name = 'training_'+veg_type+'_folder' 


    # implement keyvault in registering custom datastore
    if train_datastore_name in ws.datastores:
        train_datastore = Datastore.get(ws, train_datastore_name)
    else:
        train_datastore_storage_name = "asartpacedevstvdsm001"
        containername = "data"
        keyvault = ws.get_default_keyvault()
        access_key = keyvault.get_secret("asartpacedevstvdsm001-key")
        access_str = keyvault.get_secret("asartpacedevstvdsm001-connstr")
        train_datastore = Datastore.register_azure_blob_container(
                            workspace=ws,
                            datastore_name=train_datastore_name,
                            account_name=train_datastore_storage_name,
                            account_key=access_key,
                            container_name=containername
                            )


    train_dataset_custom = Dataset.Tabular.from_delimited_files(path=(train_datastore, ds_str), validate=False)
    train_dataset_custom = train_dataset_custom.register(
            ws,
            name=ds_register_name,
            tags={"purpose": "training input", "format": "csv"},
            create_new_version=True,
        ).as_named_input(ds_register_name)


def main():
    parser = argparse.ArgumentParser("Register Training Data")
    parser.add_argument("--blob_dir_name", type=str, dest='ds_str', help='input training data blob dir name')
    parser.add_argument("--veg_type", type=str, dest='veg_type', help='input veg type name')

    ### optional
    parser.add_argument("--training_data_store", type=str, dest='train_datastore_name', help='training_datastore name', default="vdsmtrain")
    parser.add_argument("--ds_register_name", type=str, dest='ds_register_name', help='register data name', default=None)
    parser.add_argument("--workspace", type=str, dest='ws', help='AML workspace', default=None)

    # args = parser.parse_args()
    args, _ = parser.parse_known_args()
    ds_str = args.ds_str
    veg_type = args.veg_type
    ds_register_name = args.ds_register_name
    ws = args.ws
    register_training_dataset(ds_str, veg_type)

if __name__ == '__main__':
    main()
