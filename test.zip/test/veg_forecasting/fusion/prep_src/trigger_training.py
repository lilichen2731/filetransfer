import requests
from azureml.core.authentication import MsiAuthentication
from azureml.core.run import Run

msi_auth = MsiAuthentication(identity_config = {"client_id" : 'db8e6c50-4a0f-4e53-861d-fd2d6828e0d5'})
auth_header = msi_auth.get_authentication_header()

# vdsm-train-pv_3mon-sc.pkl
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/f46281a3-cdc1-488b-8941-e2a1c6c72347'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger"})
run = Run.get_context()
run.log('response1', response.status_code)

# vdsm-train-npv_3mon-sc.pkl
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/0fc13e79-0b3f-43a2-b406-8911fb38a406'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger"})
run = Run.get_context()
run.log('response2', response.status_code)

# vdsm-train-bs_3mon-sc.pkl
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/733eb6c0-78a6-479d-b569-928d068b3c15'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger"})
run = Run.get_context()
run.log('response3', response.status_code)

# vdsm-train-pv_6mon-sc.pkl
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/08fc0c87-30c8-4a4c-86a3-8fd24477eef2'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger"})
run = Run.get_context()
run.log('response4', response.status_code)

# vdsm-train-npv_6mon-sc.pkl
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/61bac725-00dd-4615-9655-0a9082b7f88b'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger"})
run = Run.get_context()
run.log('response5', response.status_code)

# vdsm-train-bs_6mon-sc.pkl
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/0ac18f74-e554-4fbc-b6cf-0b74feae823e'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger"})
run = Run.get_context()
run.log('response6', response.status_code)

# vdsm-train-pv_12mon-sc.pkl
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/b21767b1-af3f-4356-9796-ddb2fb8b8b2f'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger"})
run = Run.get_context()
run.log('response7', response.status_code)

# vdsm-train-npv_12mon-sc.pkl
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/1f6c032b-a657-4c9b-8a2f-8fa80b987556'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger"})
run = Run.get_context()
run.log('response8', response.status_code)

# vdsm-train-bs_12mon-sc.pkl
rest_endpoint='https://australiaeast.api.azureml.ms/pipelines/v1.0/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-SpaceTech/providers/Microsoft.MachineLearningServices/workspaces/aml-WS-spacetech001/PipelineRuns/PipelineSubmit/9b4fc3b3-9593-4938-b9bb-d78401dddce1'
response = requests.post(rest_endpoint, headers=auth_header, json={"ExperimentName": "trigger"})
run = Run.get_context()
run.log('response9', response.status_code)