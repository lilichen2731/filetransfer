from fsspec.implementations.http import HTTPFileSystem
import pandas as pd
import math
import sys
import os
import time
import geopandas as gpd
from pyproj import Transformer
import pickle as pkl
import json 
import numpy as np
import rasterio
from rasterio.features import rasterize
import affine
import xarray as xr
import datetime
from dateutil.relativedelta import relativedelta
from io import StringIO

from functools import wraps

import argparse
from azureml.core.run import Run
from joblib import Parallel, delayed

from vdsm_util import mean_value_dvar, get_mask_sh, get_previous_month_string, interpolate_single_band
from vdsm_util import fill_missing_months_CO2, fill_missing_months_climate
from vdsm_util import get_blob_client, get_blobnames
from io import BytesIO
import logging
import traceback
import time

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
        
def init():
    global columns
    columns = ['year', 'month', 'evi', 'evi_prev', 'u10', 'u10_prev', 'v10', 'v10_prev', 't2m', 't2m_prev', 
            'lai_lv', 'lai_lv_prev', 'src', 'src_prev', 'ssr', 'ssr_prev', 'sp', 'sp_prev', 'e', 'e_prev', 
            'tp', 'tp_prev', 'tp_prev2', 'tp_prev3', 'swvl1', 'swvl1_prev', 'co2', 'co2_prev', 'lat_4326', 'lon_4326', 
            'season_ch_3mon', 'season_ch_6mon', 'season_ch_9mon', 'season_ch_12mon'
            ]

### Dump all the input requirements and keywords here first:
def fuse_all_infer(s2_path, fc_path, co2_path, climate_path, mask_path,
                PV=None, NPV=None, 
                pixel_cls_url=None, random_select=-1, 
                create_new_fc=True, masked_use=True, date_infer=None,
                conn_str=None,
                **kwargs):
    """Fuse 4 categories of spatiotemporal data from the blob storage.

    Parameters
    ----------
    s2_path : str
        authenticated blob url path for Sentinel-2 data. e.g. 
        s2_path = create_blob_stream(blobname, t_expire=8)
    fc_path : str
        authenticated blob url path for fractional cover data.
    co2_path : str
        authenticated blob url path for co2 data.
    climate_path : str
        authenticated blob url path for climate data.
    mask_path : str
        authenticated blob url path for masks of the railway.
    PV: boolean
        True if selecting green veg pixels
    NPV: boolean
        True if selecting non-green veg pixels.
        If non of PV and NPV is true, return bare-land pixels.           
    pixel_cls_url: str, default = None
        authenticated blob url path for a pre-classified dataframe, 
            useful to reduce computation time if you already run the code once and
            saved the random_pv_df as a file in the blob.     
    random_select : int, default value = -1
        set to >0==N if you want to return N randomly sampled pixels in random_pv_df.
    create_new_fc : boolean, default True
        set this to False if pixel_cls_url is not None.
    masked_use : boolean, default=True
        set to False to disable the use of mask_path
    date_infer : str, default=None
        set to month for inference. If None, will be set to last month

    Returns
    -------
    ds2_all, ds_env: xarray 
    co2_df, random_pv_df: dataframes
        To be used in the next step of training data assembly 
         
    To-Do:
    link a logic between pixel_cls_url with create_new_fc
    """
    if date_infer == None:
        date_infer = str(datetime.datetime.now() + relativedelta(months=-1))[:7]
        
    # Read in co2 data
    ### To-Do: find a better way to write this so that the line number like 57 is auto-detected?
    ### Need to write a error check code in case co2 table format changes

    blob_client = get_blob_client(filename=co2_path, conn_str=conn_str)
    column_names = blob_client.download_blob().readall().decode().split("\n")[57][2:].split()
    co2_df = pd.DataFrame(columns=column_names)
    
    for line in blob_client.download_blob().readall().decode().split("\n")[58:-1]:
        vals = line[2:-1].split()
        dict_vals = {}
        for i in range(len(column_names)):
            dict_vals[column_names[i]] = vals[i]
        co2_df = co2_df.append(dict_vals, ignore_index=True) 
    
    co2_df['month-year'] = co2_df['year'].astype('str') + '-' + co2_df['month'].astype('str').str.rjust(2,'0')
    co2_df = co2_df.set_index(['month-year'])
    co2_df.drop(columns=['year', 'month', 'decimal', 'trend'], inplace=True)
    co2_df['average'] = co2_df['average'].astype('float')
    co2_df = fill_missing_months_CO2(co2_df, date_infer)
    print(co2_df)

    # Read in climate data
    blob_client = get_blob_client(filename=climate_path, conn_str=conn_str)
    ds_env = pkl.loads(blob_client.download_blob().content_as_bytes())
    ds_env = ds_env.drop(['lai_hv'])   # cuz lai_hv column is problematic, mostly zeros
    ds_env = fill_missing_months_climate(ds_env, date_infer)
    print(ds_env)

    # Read in S2 data (minimal time range: 2015-12 to 2021-07)
    blob_client = get_blob_client(filename=s2_path, conn_str=conn_str)
    ds2_all = pkl.loads(blob_client.download_blob().content_as_bytes())
    # to do, write a if else here
    ds2_all['evi'] = 2.5*((ds2_all.nbart_nir_1 - ds2_all.nbart_red) / (ds2_all.nbart_nir_1 + 6*ds2_all.nbart_red - 7.5*ds2_all.nbart_blue +1))
    print(ds2_all)

    # Read in fractional cover data
    blob_client = get_blob_client(filename=fc_path, conn_str=conn_str)
    ds_fc = pkl.loads(blob_client.download_blob().content_as_bytes())
    print(ds_fc)
    
    # Read in mask
    blob_client = get_blob_client(filename=mask_path, conn_str=conn_str)
    gdf = gpd.read_file(StringIO(blob_client.download_blob().content_as_text()))
    gdf_3577 = gdf.to_crs("EPSG:3577")
    mask = get_mask_sh(ds2_all, gdf_3577)
    ds_fc_m = ds_fc.where(mask)
    ds_s2_m = ds2_all.where(mask)

    # Conditions are set with error bars in mind. pv+ npv + bs != 100 cuz of error bars.
    if create_new_fc:
        ds_fc_time_median = ds_fc.median(dim='time', skipna=True)

        cond_pv = (ds_fc_time_median['PV_PC_90'] >= 20) & (ds_fc_time_median['BS_PC_90'] < 60)
        filt1 = (ds_fc_time_median['NPV_PC_90'] >= 45) & (ds_fc_time_median['PV_PC_90'] < 20)
        filt2 =  ds_fc_time_median['BS_PC_90'] < 60
        cond_npv = (filt1 & filt2) 
        cond_bs = (ds_fc_time_median['NPV_PC_90'] < 45) & (ds_fc_time_median['BS_PC_90'] >= 60)

        # for missing pixels:
        filt1 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['PV_PC_90'] > ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['NPV_PC_90']
        filt2 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['PV_PC_90'] >= ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['BS_PC_90']
        filt3 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['PV_PC_90'] >= ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['NPV_PC_90']
        filt4 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['PV_PC_90'] > ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['BS_PC_90']
        missing_cond_pv = (filt1 & filt2) | (filt3 & filt4)

        filt1 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['NPV_PC_90'] >= ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['PV_PC_90']
        filt2 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['NPV_PC_90'] >= ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['BS_PC_90']
        missing_cond_npv = (filt1 & filt2)

        filt1 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['BS_PC_90'] > ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['PV_PC_90']
        filt2 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['BS_PC_90'] >= ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['NPV_PC_90']
        filt3 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['BS_PC_90'] >= ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['PV_PC_90']
        filt4 = ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['BS_PC_90'] > ds_fc_time_median.where(~cond_pv & ~cond_npv & ~cond_bs)['NPV_PC_90']
        missing_cond_bs = (filt1 & filt2) | (filt3 & filt4)

        if masked_use:
            mds_fc_time_median = ds_fc_m.median(dim='time', skipna=True)   ## for masked regions
            if PV:
                mcony = mds_fc_time_median['PV_PC_90'].where((cond_pv | missing_cond_pv), drop=True).squeeze()
            elif NPV:
                mcony = mds_fc_time_median['PV_PC_90'].where((cond_npv | missing_cond_npv), drop=True).squeeze()
            else:
                mcony = mds_fc_time_median['PV_PC_90'].where((cond_bs | missing_cond_bs), drop=True).squeeze()
        else:        
            if PV:
                mcony = ds_fc_time_median['PV_PC_90'].where((cond_pv | missing_cond_pv), drop=True).squeeze()
            elif NPV:
                mcony = ds_fc_time_median['PV_PC_90'].where((cond_npv | missing_cond_npv), drop=True).squeeze()
            elif NPV:
                mcony = ds_fc_time_median['PV_PC_90'].where((cond_bs | missing_cond_bs), drop=True).squeeze()

        mcony_df = mcony.to_dataframe().dropna()
        mcony_df.reset_index(inplace=True)
        mcony_df.drop_duplicates(subset=['y','x'], keep='first', inplace=True)
        transformer = Transformer.from_crs("EPSG:3577", "EPSG:4326")
        y_4326, x_4326 = transformer.transform(mcony_df.x.values, mcony_df.y.values)
        mcony_df['y_4326'] = y_4326
        mcony_df['x_4326'] = x_4326

        ### random samples
        if random_select > 0:
            random_pv_df = mcony_df.sample(n=random_select, replace=False)
        else:
            random_pv_df = mcony_df.copy()
    else:
        random_pv_df = pd.read_csv(pixel_cls_url)

    return ds2_all, ds_env, co2_df, random_pv_df


def paralle_pixel_infer(s2_lat, s2_lon, s2_lat_4326, s2_lon_4326, 
                        ds2_all=None, ds_env=None, co2_df=None, date_infer=None):
    """
    Purpose: create a dataframe with columns of features for training
    Parameters: 
    ------ 
    s2_lat, s2_lon: float, input coordinates of one pixel in CRS 3577
    s2_lat_4326, s2_lon_4326: float, input coordinates of one pixel in CRS4326
    ds2_all, ds_env: xarray, fused data from fuse_all()
    co2_df: dataframe, fused data from fuse_all()
    date_infer: date for inference, must be in year-month str format like "2021-08"
    -----
    Return:
    A dataframe with rows representing a time, and columns representing features
    The function is parallelisable. 

    """
    if date_infer is None:
        date_infer = '2021-08'
    pixel_df = pd.DataFrame(columns=columns)
    ds2_tmax = ds2_all.coords['time'].max().data
    ds2_tmin = ds2_all.coords['time'].min().data
    ds2_tmax_str = str(ds2_tmax)[:7]
    ds2_tmin_str = str(ds2_tmin)[:7]
    ds2_tmax_dt = str((pd.period_range(ds2_tmax_str, ds2_tmax_str, freq='M')-12+12)[0])
    ds2_tmin_dt = str((pd.period_range(ds2_tmin_str, ds2_tmin_str, freq='M')-12+12)[0])
    ds2_infer_dt_1yrago = str((pd.period_range(date_infer, date_infer, freq='M')-12)[0])
    # ds2 must include timeseries of 1 yr back for collecting features
    assert ds2_tmin_dt <= ds2_infer_dt_1yrago

    dataset_dict = {}

    month_p = str((pd.period_range(date_infer, date_infer, freq='M')-1)[0])
    dataset_dict[-1] = ds2_all.sel(x=s2_lon, y=s2_lat, time=month_p, method='nearest')  

    bad_index = [-999]
    count = 0
    year = int(date_infer[0:4])
    month = int(date_infer[-2:])
    date = (str(year)+'-'+str(month).rjust(2,'0'))
    dataset_dict[count] = ds2_all.sel(x=s2_lon, y=s2_lat, time=date, method='nearest')
    dataset_dict[count] = dataset_dict[count].drop_vars(['nbart_red', 'nbart_blue', 'nbart_nir_1'])

    try:
        checklen = len(dataset_dict[count].evi.data)
    except:
        checklen = dataset_dict[count].evi.data.size
    if isinstance(checklen, int) and checklen == 0:
        bad_index.append(count)
        print(f'Warning!!! Year-Month {date} has no data, count is {count}!!!')
    if isinstance(checklen, tuple) and checklen[0] == 0:  
        bad_index.append(count)
        print(f'Warning!!! Year-Month {date} has no data, count is {count}!!!')
    count = count + 1

    for bad_index in bad_index:
        if bad_index > -1:
            dataset_dict[bad_index] = np.NaN   ### fix the warning
            # dataset_dict[bad_index] = dataset_dict[bad_index+1]   ### fix the warning

    count = 0
    # this dictionary gets added as a row to the pixel_df dataframe
    pd_vars = {}
    year = int(date_infer[0:4])
    month = int(date_infer[-2:])
#             print('checking ------', str(dataset_dict[count+oh 0].time[0].data))
    pd_vars['year'] = year  #int(str(dataset_dict[count+0].time[0].data)[:4])
    pd_vars['month'] = month  #int(str(dataset_dict[count+0].time[0].data)[5:7])

    #### TTY adding extra info here, should be outside of the loop
    pd_vars['lat_4326'] = s2_lat_4326
    pd_vars['lon_4326'] = s2_lon_4326

    month_year = str(pd_vars['year']) + '-' + str(pd_vars['month']).rjust(2, '0')
    previous_month_year = get_previous_month_string(month_year)

    pd_vars['evi_prev'] = mean_value_dvar(dataset_dict[count-1], var='evi')
    pd_vars['evi'] = mean_value_dvar(dataset_dict[count+0], var='evi')

    for band in ds_env.data_vars:
        pd_vars[band] = interpolate_single_band(ds_env, s2_lat, s2_lon, band, month_year)
        pd_vars[band+'_prev'] = interpolate_single_band(ds_env, s2_lat, s2_lon, band, previous_month_year)

    pd_vars['tp_prev2'] = interpolate_single_band(ds_env, s2_lat, s2_lon, 'tp', get_previous_month_string(previous_month_year))
    pd_vars['tp_prev3'] = interpolate_single_band(ds_env, s2_lat, s2_lon, 'tp', get_previous_month_string(get_previous_month_string(previous_month_year)))
    pd_vars['co2'] = co2_df.loc[month_year]['average']
    pd_vars['co2_prev'] = co2_df.loc[previous_month_year]['average']
        
    t_12mon_ago = str((pd.period_range(month_year, month_year, freq='M')-12)[0])
    t_12mon_ago_add3 = str((pd.period_range(month_year, month_year, freq='M')-12+3)[0])
    t_12mon_ago_add6 = str((pd.period_range(month_year, month_year, freq='M')-12+6)[0])
    t_12mon_ago_add9 = str((pd.period_range(month_year, month_year, freq='M')-12+9)[0])
    t_12mon_ago_add12 = str((pd.period_range(month_year, month_year, freq='M')-12+12)[0])
    
    ds_12mon_ago = ds2_all.sel(x=s2_lon, y=s2_lat, time=t_12mon_ago, method='nearest')
    ds_12mon_ago_add3 = ds2_all.sel(x=s2_lon, y=s2_lat, time=t_12mon_ago_add3, method='nearest')
    ds_12mon_ago_add6 = ds2_all.sel(x=s2_lon, y=s2_lat, time=t_12mon_ago_add6, method='nearest')
    ds_12mon_ago_add9 = ds2_all.sel(x=s2_lon, y=s2_lat, time=t_12mon_ago_add9, method='nearest')
    ds_12mon_ago_add12 = ds2_all.sel(x=s2_lon, y=s2_lat, time=t_12mon_ago_add12, method='nearest')
                    
    pd_vars['season_ch_3mon'] = mean_value_dvar(ds_12mon_ago_add3, var='evi') - mean_value_dvar(ds_12mon_ago, var='evi')
    pd_vars['season_ch_6mon'] = mean_value_dvar(ds_12mon_ago_add6, var='evi') - mean_value_dvar(ds_12mon_ago, var='evi')
    pd_vars['season_ch_9mon'] = mean_value_dvar(ds_12mon_ago_add9, var='evi') - mean_value_dvar(ds_12mon_ago, var='evi')
    pd_vars['season_ch_12mon'] = mean_value_dvar(ds_12mon_ago_add12, var='evi') - mean_value_dvar(ds_12mon_ago, var='evi')
    
    pixel_df = pixel_df.append(pd_vars, ignore_index=True)
    count = count + 1

    return pixel_df

def run(df):

    run = Run.get_context()
    conn_str = run.get_secret("asartpacedevstvdsm001-connstr")

    l = []

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--month",
        type=str,
        dest='month'
    )
    parser.add_argument(
        "--random_n",
        type=int,
        dest='random_n'
    )
    parser.add_argument(
        "--PV",
        dest='PV',
        choices=("True", "False"),
        help=("Set true for green veg,\
               if bare land, set False for both PV, NPV")
    )
    parser.add_argument(
        "--NPV",
        dest='NPV',
        choices=("True", "False"),
        help=("Set true for non-green veg,\
               if bare land, set False for both PV, NPV")
    )
    
    args, _ = parser.parse_known_args()
    month = args.month
    PV = args.PV == "True"
    NPV = args.NPV == "True"
    random_n = args.random_n
    # random_n = -1 #need all pixels for inference
    veg_type = 'pv'
    if NPV:
        veg_type = 'npv'
    if not NPV and not PV:
        veg_type = 'bs'

    climate_path = 'climate/{}.pkl'.format(month)
    co2_path = 'co2/{}.txt'.format(month)
    mask_path = 'static/RTiO_ChainageAreas_1KM_30M.json'

    start_month = str(int(month[:4])-1) + '-' + month[-2:]

    for index, row in df.iterrows():

        print(row)
        print(row['name'])

        fc_path = 'static/fractional-cover/{}_fc.pkl'.format(row['name'])
        s2_path = '{}/{}/merged/{}_S2_{}_{}.pkl'.format(month[:4], month[5:7], row['name'], start_month, month)

        save_folder = '{}/{}/fused/{}_v1'.format(month[:4], month[5:7], veg_type)
        save_file = '{}.csv'.format(row['name'])

        # if len(get_blobnames(save_folder + '/' + save_file, conn_str=conn_str)) > 0:
        #     print(save_folder + '/' + save_file)
        #     continue

        # to do: shall we auto detect month as the max dates of ds2_all?
        ds2_all, ds_env, co2_df, random_pv_df = fuse_all_infer(s2_path, fc_path, co2_path,
                                        climate_path, mask_path, PV=PV, NPV=NPV, date_infer=month, conn_str=conn_str)
        init()
        if random_n > 0:
            try:
                random_pv_df_infer = random_pv_df.sample(n=random_n, replace=False)
            except:
                # print(f"################## number of pixels selected per region {len(random_pv_df.index)}")
                random_pv_df_infer = random_pv_df.copy()
        else:
            random_pv_df_infer = random_pv_df.copy()

        results = []

        # try:
        exists=False

        for i in range(0, random_pv_df_infer.shape[0]//2000+1):
            random_pv_df_input = random_pv_df_infer.copy()
            random_pv_df_input_slice = random_pv_df_input.iloc[i*2000:min(len(random_pv_df_infer),(i+1)*2000)]
            for s2_lat, s2_lon, s2_lat_4326, s2_lon_4326 in zip(random_pv_df_input_slice.y, random_pv_df_input_slice.x, random_pv_df_input_slice.y_4326, random_pv_df_input_slice.x_4326):
                res = paralle_pixel_infer(s2_lat, s2_lon, s2_lat_4326, s2_lon_4326, ds2_all=ds2_all, ds_env=ds_env, co2_df=co2_df, date_infer=month)
                results.append(res)
            df_all_pv = pd.concat(results)

            df_use = df_all_pv.copy()
            assert df_use.shape[0] > 0

            ### Drop unused columns
            year_col = df_use["year"]
            lat_col = df_use["lat_4326"]
            lon_col = df_use["lon_4326"]
            if df_use.columns[0] != "year":
                df_use.drop(columns=df_use.columns[0], axis=1, inplace=True)
            dropped_names = ["lat_4326", "lon_4326"]
            df_use.drop(columns=dropped_names, axis=1, inplace=True)

            ### Drop the Year column as it cannot be a feature in forecasting models
            X = df_use.iloc[:, 1:].values
            print(f" ******Debug: What is the shape of X:  {X.shape}")
            # construct a fake array to hold 12 month for OneHotEncoder
            X_mon = np.zeros((12, X.shape[1]))
            X_mon[0:12, 0] = np.arange(1,13)
            X_infer =np.concatenate((X_mon[0:12, :], X))
            print(f" ******Debug: What is the shape of X_infer before onehot:  {X_infer.shape}")
            ct = ColumnTransformer(transformers=[('encoder', OneHotEncoder(sparse=False), [0])], remainder='passthrough')
            X_infer = np.array(ct.fit_transform(X_infer))
            print(f" ******Debug: What is the shape of X_infer after onehot:  {X_infer.shape}")
            X_infer_valid = X_infer[12:, :]
            print(f" ******Debug: What is the shape of X_infer_valid:  {X_infer_valid.shape}")

            cols = list(df_use.columns[2:])
            for i in range(12,0,-1):
                cols.insert(0, 'month{}'.format(str(i)))

            df_numpy = pd.DataFrame(data=X_infer_valid, columns=cols)

            df_numpy.insert(0, 'year', year_col.values)
            df_numpy.insert(0, 'lon', lon_col.values)
            df_numpy.insert(0, 'lat', lat_col.values)
            df_numpy.insert(0, 'filename', save_file)

            if exists:
                existing_df = pd.read_csv(StringIO(blob_client.download_blob().content_as_text()))
                df_numpy = existing_df.append(df_numpy)

            save_path = os.path.join(save_folder, save_file)
            output = df_numpy.to_csv(index=False, encoding='utf-8', header=True)

            blob_client = get_blob_client(filename=save_path, conn_str=conn_str)
            blob_client.upload_blob(output, overwrite=True, blob_type='BlockBlob')
            exists = True

        # blob_client = write_blob_client(save_path, '')
        # blob_client.upload_blob(output, overwrite=True, blob_type='BlockBlob')

        l.append(True)

        # except:
        #     print(traceback.format_exc())
        #     blob_client = get_blob_client(filename='stdout.txt', conn_str=conn_str)
        #     blob_client.upload_blob(traceback.format_exc(), overwrite=True, blob_type='BlockBlob')

        # run.tag("run_type", value="fuse_data_for_training")
        # print(f"tags now present for run: {run.tags}")
        # run.complete()

    return l

if __name__ == '__main__':
    main()
