import datetime
from dateutil.relativedelta import relativedelta
from vdsm_util import get_blob_client, create_target_dataset
import pickle as pkl
from azure.storage.blob import BlobServiceClient
import pandas as pd
from io import StringIO
import traceback


def create_target_dataset(end_month, veg_type='pv', conn_str=None, write_to_blob=True):

    blob_client = BlobServiceClient.from_connection_string(conn_str)
    container_client = blob_client.get_container_client("data")

    end_month_dt = datetime.date(int(end_month[:4]), int(end_month[5:]), 1)
    start_month_dt = datetime.date(int(end_month[:4]), int(end_month[5:]), 1) + relativedelta(months=-12)

    months = []
    month_dt = start_month_dt
    while month_dt < end_month_dt:
        month_dt = month_dt + relativedelta(months=1)
        months.append(str(month_dt)[:7])

    target_df = pd.DataFrame()

    for month in months:

        blob_names = container_client.list_blobs(name_starts_with=f'{month[:4]}/{month[5:]}/fused/{veg_type}_v1')

        for blob_name in blob_names:
            blob_client = get_blob_client(filename=blob_name, conn_str=conn_str)
            df = pd.read_csv(StringIO(blob_client.download_blob().content_as_text()))
            if datetime.date(int(end_month[:4]), int(end_month[5:]), 1) >= datetime.date(2021, 12, 1):
                try:
                    df = df.sample(n=100)
                except:
                    pass
            target_df = target_df.append(df)

    target_df.drop(columns=['filename', 'lat', 'lon'], inplace=True)
    target_df.insert(1, 'month', target_df.iloc[:, 1:13].values.argmax(axis=1) + 1)
    target_df.drop(columns=['month1','month2','month3','month4','month5','month6','month7','month8','month9','month10','month11','month12'], inplace=True)

    output = target_df.to_csv(index=False, encoding='utf-8', header=True)

    blob_client = get_blob_client(filename=f'data_drift/target/{end_month}/{veg_type}.csv', conn_str=conn_str)
    blob_client.upload_blob(output, overwrite=True, blob_type='BlockBlob')

def main():


    