"""
Copyright (C) Microsoft Corporation. All rights reserved.​
 ​
Microsoft Corporation (“Microsoft”) grants you a nonexclusive, perpetual,
royalty-free right to use, copy, and modify the software code provided by us
("Software Code"). You may not sublicense the Software Code or any use of it
(except to your affiliates and to vendors to perform work on your behalf)
through distribution, network access, service agreement, lease, rental, or
otherwise. This license does not purport to express any claim of ownership over
data you may have shared with Microsoft in the creation of the Software Code.
Unless applicable law gives you more rights, Microsoft reserves all other
rights not expressly granted herein, whether by implication, estoppel or
otherwise. ​
 ​
THE SOFTWARE CODE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
MICROSOFT OR ITS LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THE SOFTWARE CODE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
"""
import os
import re
from datetime import datetime, timedelta, date, timezone
import dateutil.relativedelta as dtrel

import json 
import random
import string

from azureml.pipeline.steps import ParallelRunConfig, ParallelRunStep
from ml_service.util.manage_environment import get_environment
from ml_service.pipelines.load_sample_data import create_sample_data_csv
from ml_service.util.env_variables import Env
from ml_service.util.attach_compute import get_compute
from azureml.core import (
    Workspace,
    Dataset,
    Datastore,
    RunConfiguration,
)
from azureml.pipeline.core import Pipeline, PipelineData, PipelineParameter
from azureml.core.compute import ComputeTarget
from azureml.data.datapath import DataPath
from azureml.pipeline.steps import PythonScriptStep
from typing import Tuple

from azureml.core.authentication import MsiAuthentication

# VDSM no longer uses this function
def get_or_create_datastore(
    datastorename: str, ws: Workspace, env: Env, input: bool = True
) -> Datastore:
    """
    Obtains a datastore with matching name. Creates it if none exists.

    :param datastorename: Name of the datastore
    :param ws: Current AML Workspace
    :param env: Environment variables
    :param input: Datastore points to the input container if
    this is True(default) or the output storage container otherwise

    :returns: Datastore

    :raises: ValueError
    """
    if datastorename is None:
        raise ValueError("Datastore name is required.")

    containername = (
        env.scoring_datastore_input_container
        if input
        else env.scoring_datastore_output_container
    )

    if datastorename in ws.datastores:

        datastore = ws.datastores[datastorename]

    # the datastore is not registered but we have all details to register it
    elif (
        env.scoring_datastore_access_key is not None
        and containername is not None  # NOQA: E501
    ):  # NOQA:E501

        datastore = Datastore.register_azure_blob_container(
            workspace=ws,
            datastore_name=datastorename,
            account_name=env.scoring_datastore_storage_name,
            account_key=env.scoring_datastore_access_key,
            container_name=containername,
        )
    else:
        raise ValueError(
            "No existing datastore named {} nor was enough information supplied to create one.".format(  # NOQA: E501
                datastorename
            )
        )

    return datastore

# VDSM only calls this function as a placeholder
def get_input_dataset(ws: Workspace, ds: Datastore, env: Env) -> Dataset:
    """
    Gets an input dataset wrapped around an input data file. The input
    data file is assumed to exist in the supplied datastore.


    :param ws: AML Workspace
    :param ds: Datastore containing the data file
    :param env: Environment variables

    :returns: Input Dataset

    TTcomment: for VDSM we only use this func as a placeholder.
    """

    # Register a dataset for the input data
    scoringinputds = Dataset.Tabular.from_delimited_files(path=(ws.get_default_datastore(), 'scoringinput_bs/*'), validate=False)

    scoringinputds = scoringinputds.register(
        ws,
        name=env.scoring_dataset_name,
        tags={"purpose": "scoring input", "format": "csv"},
        create_new_version=True,
    ).as_named_input(env.scoring_dataset_name)


    return scoringinputds


# VDSM no longer uses this function
def get_fallback_input_dataset(ws: Workspace, env: Env) -> Dataset:
    """
    Called when an input datastore does not exist or no input data file exists
    at that location. Create a sample dataset using the veg_forecasting
    dataset from
    scikit-learn. Useful when debugging this code in the absence of the input
    data location Azure blob.


    :param ws: AML Workspace
    :param env: Environment Variables

    :returns: Fallback input dataset

    :raises: FileNotFoundError
    """

    default_datastore = ws.get_default_datastore()
    # Register a dataset for the input data
    scoringinputds = Dataset.Tabular.from_delimited_files(path=(default_datastore, 'scoringinput_bs/*'), validate=False)
    print(' WARNINGING!!! --- using fallback function:', scoringinputds)
    scoringinputds = scoringinputds.register(
        ws,
        name=env.scoring_dataset_name,
        tags={"purpose": "scoring input", "format": "csv"},
        create_new_version=True,
    ).as_named_input(env.scoring_dataset_name)

    return scoringinputds


def get_output_location(
    ws: Workspace, env: Env, outputdatastore: Datastore = None
) -> PipelineData:
    """
    Returns a Datastore wrapped as a PipelineData instance suitable
    for passing into a pipeline step. Represents the location where
    the scoring output should be written. Uses the default workspace
    blob store if no output datastore is supplied.


    :param ws: AML Workspace
    :param env: Environment Variables
    :param outputdatastore: AML Datastore, optional, default is None

    :returns: PipelineData wrapping the output datastore
    """

    if outputdatastore is None:
        output_loc = PipelineData(
            name=f"output_loc_{output_str}", datastore=ws.get_default_datastore()
        )
    else:
        output_str = ''.join(random.SystemRandom().choice(string.ascii_letters + string.digits) for _ in range(3))
        output_loc = PipelineData(
            name=f"output_loc_{output_str}", datastore=ws.get_default_datastore()
        )  # NOQA: E501

    return output_loc


def get_inputds_outputloc(
    ws: Workspace, env: Env
) -> Tuple[Dataset, PipelineData]:  # NOQA: E501
    """
    Prepare the input and output for the scoring step. Input is a tabular
    dataset wrapped around the scoring data. Output is PipelineData
    representing a location to write the scores down.

    :param ws: AML Workspace
    :param env: Environment Variables

    :returns: Input dataset and output location
    """
    inputdatastore = ws.get_default_datastore()
    outputdatastore = ws.get_default_datastore()
    if env.scoring_datastore_storage_name is None:
        scoringinputds = None  # get_input_dataset(ws, inputdatastore, env)
        output_loc = get_output_location(ws, env, outputdatastore)

    else:
        scoringinputds = None  #get_input_dataset(ws, inputdatastore, env)
        output_loc = get_output_location(ws, env, outputdatastore)

    return (scoringinputds, output_loc)


def get_run_configs(
    ws: Workspace, computetarget: ComputeTarget, env: Env
) -> Tuple[ParallelRunConfig, RunConfiguration]:
    """
    Creates the necessary run configurations required by the
    pipeline to enable parallelized scoring.

    :param ws: AML Workspace
    :param computetarget: AML Compute target
    :param env: Environment Variables

    :returns: Tuple[Scoring Run configuration, Score copy run configuration]
    """

    environment = get_environment(
        ws,
        env.aml_env_name_scoring,
        conda_dependencies_file=env.aml_env_score_conda_dep_file,
        enable_docker=True,
        use_gpu=env.use_gpu_for_scoring,
        create_new=env.rebuild_env_scoring,
    )

    # VDSM uses default mini_batch_size
    score_run_config = ParallelRunConfig(
        entry_script=env.batchscore_script_path,
        source_directory=env.sources_directory_train,
        error_threshold=10,
        output_action="append_row",
        append_row_file_name='parallel_run_step.txt', 
        compute_target=computetarget,
        # node_count=env.max_nodes_scoring,
        environment=environment,
        run_invocation_timeout=300,
        # mini_batch_size=4,
        node_count=env.max_nodes_scoring,
        process_count_per_node=4,
        logging_level='DEBUG'
    )

    copy_run_config = RunConfiguration()
    copy_run_config.environment = get_environment(
        ws,
        env.aml_env_name_score_copy,
        conda_dependencies_file=env.aml_env_scorecopy_conda_dep_file,
        enable_docker=True,
        use_gpu=env.use_gpu_for_scoring,
        create_new=env.rebuild_env_scoring,
    )
    return (score_run_config, copy_run_config)


def get_scoring_pipeline(
    scoring_dataset: Dataset,
    output_loc: PipelineData,
    score_run_config: ParallelRunConfig,
    copy_run_config: RunConfiguration,
    computetarget: ComputeTarget,
    ws: Workspace,
    env: Env,
) -> Pipeline:
    """
    Creates the scoring pipeline.

    :param scoring_dataset: Data to score == None. VDSM doesn't use this.
    :param output_loc: Location to save the scoring results
    :param score_run_config: Parallel Run configuration to support
    parallelized scoring
    :param copy_run_config: Script Run configuration to support
    score copying
    :param computetarget: AML Compute target
    :param ws: AML Workspace
    :param env: Environment Variables

    :returns: Scoring pipeline instance
    """

    if env.score_model_version is None:
        model_version_int = 4
    else:
        model_version_int = int(env.score_model_version)

    if (env.scoring_test_mode).lower() == "true":
        # test using one model only
        model_names = ['vdsm-train-bs_12mon-sc.pkl'
                    ]
        model_versions = [model_version_int]
    else:
        #  :loop over 8 model names and lists below
        model_names = ['vdsm-train-pv_3mon-sc.pkl',
                        'vdsm-train-pv_6mon-sc.pkl',
                        'vdsm-train-pv_12mon-sc.pkl',
                        'vdsm-train-npv_3mon-sc.pkl',
                        'vdsm-train-npv_6mon-sc.pkl',
                        'vdsm-train-npv_12mon-sc.pkl',
                        'vdsm-train-bs_3mon-sc.pkl',
                        'vdsm-train-bs_6mon-sc.pkl',
                        'vdsm-train-bs_12mon-sc.pkl']
        model_versions = [model_version_int]*len(model_names)


    model_tag_name_param = " "
    model_tag_value_param = " "

    # implement keyvault in registering custom datastore
    if env.scoring_datastore_name in ws.datastores:
        score_datastore = Datastore.get(ws, env.scoring_datastore_name)
    else:
        keyvault = ws.get_default_keyvault()
        access_key = keyvault.get_secret(env.scoring_datastore_access_key)
        score_datastore = Datastore.register_azure_blob_container(
                            workspace=ws,
                            datastore_name=env.scoring_datastore_name,
                            account_name=env.scoring_datastore_storage_name,
                            account_key=access_key,
                            container_name=env.scoring_datastore_input_container
                            )


    scoring_copying_steps = []

    for model_name, model_version in zip(model_names, model_versions):
        output_str = ''.join(random.SystemRandom().choice(string.ascii_letters + string.digits) for _ in range(3))

        # output_loc_rand specifies where the output scoring data is going to be stored
        output_loc_rand= PipelineData(
               name=f"output_loc_{output_str.lower()}", datastore=ws.get_default_datastore()
        )
        model_str = re.split('-', model_name)[2].split('_')
        veg_type = model_str[0]
        month_str = re.findall('[0-9]+', model_str[1])
        month_int = int(month_str[0])
        
        # get dataset name that matches one of the 8 models
        # we only infer data that were fused one month ago
        f_year = (datetime.today() + dtrel.relativedelta(months=-1)).year
        f_prev_month = (datetime.today() + dtrel.relativedelta(months=-1)).month

        f_prev_month_user = env.scoring_manual_month
        f_year_user = env.scoring_manual_year
        ds_str_user = f'{f_year_user}/{int(f_prev_month_user):02d}/fused/{veg_type}_v1/*'

        if (env.scoring_test_mode).lower() == "true":
            # for testing the old version
            # ds_str = f'scoringinput_{veg_type}/*'
            ds_str = 'tmp/scoringinput/*'
        else:
            if (env.scoring_auto_mode).lower() == "true":
                # example 2021/12/fused/npv_v1/*
                ds_str = f'{f_year}/{int(f_prev_month):02d}/fused/{veg_type}_v1/*'
            else:
                ds_str = ds_str_user


        if score_datastore == None:
            score_datastore = ws.get_default_datastore()

        try:    
            scoring_dataset_custom = Dataset.Tabular.from_delimited_files(path=(score_datastore, ds_str), validate=False)
        except:
            print('Auto-scoring disabled, activate User-defined scoring dataset: ', ds_str_user)
            scoring_dataset_custom = Dataset.Tabular.from_delimited_files(path=(score_datastore, ds_str_user), validate=False)

        scoring_dataset_custom = scoring_dataset_custom.register(
            ws,
            name='scoring_'+veg_type,
            tags={"purpose": "scoring input", "format": "csv"},
            create_new_version=True,
        ).as_named_input('scoring_'+veg_type)

        scoring_step = ParallelRunStep(
        name=f"scoring{veg_type}{month_int}",
        inputs=[scoring_dataset_custom],
        output=output_loc_rand,
        arguments=[
            "--model_name",
            model_name,
            "--model_version",
            model_version,
            "--model_tag_name",
            model_tag_name_param,
            "--model_tag_value",
            model_tag_value_param,
            ],
        parallel_run_config=score_run_config,
        allow_reuse=False,
        )

        copying_step = PythonScriptStep(
            name=f"scopy{veg_type}{month_int}",
            script_name=env.batchscore_copy_script_path_up,
            source_directory=env.sources_directory_batchcopy,
            arguments=[
                "--model_name",
                model_name,
                "--model_version",
                model_version,
                "--output_path",
                output_loc_rand,
                ], 
            inputs=[output_loc_rand],
            allow_reuse=False,
            compute_target=computetarget,
            runconfig=copy_run_config,
        )
        
        scoring_copying_steps.append(scoring_step)
        scoring_copying_steps.append(copying_step)
        
    return Pipeline(workspace=ws, steps=scoring_copying_steps)


def build_batchscore_pipeline():
    """
    Main method that builds and publishes a scoring pipeline.
    """

    try:
        env = Env()
        # msi_auth = MsiAuthentication()
        # Get Azure machine learning workspace
        aml_workspace = Workspace.get(
            name=env.workspace_name,
            subscription_id=env.subscription_id,
            resource_group=env.resource_group,
        )

        # Get Azure machine learning cluster
        aml_compute_score = get_compute(
            aml_workspace,
            env.compute_name_scoring,
            env.vm_size_scoring,
            for_batch_scoring=True,
        )

        input_dataset, output_location = get_inputds_outputloc(
            aml_workspace, env
        )  # NOQA: E501

        scoring_runconfig, score_copy_runconfig = get_run_configs(
            aml_workspace, aml_compute_score, env
        )

        scoring_pipeline = get_scoring_pipeline(
            input_dataset,
            output_location,
            scoring_runconfig,
            score_copy_runconfig,
            aml_compute_score,
            aml_workspace,
            env,
        )

        published_pipeline = scoring_pipeline.publish(
            name=env.scoring_pipeline_name,
            description="Veg Forecasting Batch Scoring Pipeline",
        )
        pipeline_id_string = "##vso[task.setvariable variable=pipeline_id;isOutput=true]{}".format(  # NOQA: E501
            published_pipeline.id
        )

        print("##### Pipeline_id_string: ", pipeline_id_string)
        rest_endpoint = published_pipeline.endpoint
        print("##### Pipeline Rest endpoint: ", rest_endpoint)

    except Exception as e:
        print(e)
        exit(1)


if __name__ == "__main__":
    build_batchscore_pipeline()