# Logger Usage information
## Introduction
This is a guide for developers intending to modify the source code of the logger or deploy it within their own environment. This logger is 
designed to workspaceacross any AML workspace, be that on a compute instance or in a pipeline. It is also designed to work in a function app.  
For a demonstration of the usage of the vdsm_logger module, please see `logger_user_guide.ipynb`.

Changes to the source code should be made sparingly, as the capitalised variables near the top of the file `vdsm_logger.py` allow for the required
modularity.

## Changing the SQL database
This logger obtains connects to a database by accessing an an Azure Key Vault and accessing a connection string stored as a secret from this resource.
The name of the secret is stored in the code as `CONN_STRING_NAME`. If changing to a different database, change the value of this secret in the Azure KeyVault
to the ODBC connection string given by the new database.  

Note that this logger automatically uses the default Key Vault when running inside an AML workspace. This is required by the methods used to authenticate access 
to these resources. The function app uses a managed identity to access the AML default Azure Key Vault, whose parameters are assigned in the variables `KEY_VAULT_NAME`, 
`MANAGED_CLIENT_ID`. The former is the name of the target key vault, and the latter is the client id of the managed identity accessing it. 

### Changing the table
If a new table within the same database, or a table of a different name outside of the database is to be used instead, the `TABLE_NAME` variable should be changed.
The value `DESCRIPTION_SIZE_BYTES` should be set to the size of the `description` column in the database. This is the size that long error messages should be truncated to, in bytes.

## Changing the AML workspace
When deploying this service in a new workspace, the parameters `WS_SUBSCRIPTION_ID`, `WS_RESOURCE_GROUP`, and `WS_NAME` should be changed to reflect those of the current workspace.
This is only strictly necessary when running this module from a compute instance, however it is recommended that they are always up to date to reflect the resource's values