class Error(Exception):
    """base class for user-defined exceptions"""
    pass

class MissingDataError(Error):
    """Raised when data required for logging is not present"""
    pass

class KeyVaultConnectionError(Error):
    """Raised when the connection string is unable to be obtained from the key vault"""
    pass

class DatabaseConnectionError(Error):
    """Raised when the connection string is unable to be obtained from the key vault"""
    pass
