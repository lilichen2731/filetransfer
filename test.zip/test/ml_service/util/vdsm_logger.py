"""
1. Read in data from the pipelines
    - How do we validate that we have all the data that we need 
2. Then write these to SQL database
"""
from ml_service.util.exceptions import MissingDataError, KeyVaultConnectionError, DatabaseConnectionError
from pandas.errors import EmptyDataError
import csv
from datetime import datetime
import os
import pandas as pd
import traceback
import numpy as np
import pyodbc

from azureml.core.authentication import MsiAuthentication
from azureml.core import Workspace
from azureml.core.run import Run

# when class is called
# TODO: redo this table
job_name_lookup = {
    1 : "Ingest new data",
    2 : "Merge new data",
    3 : "Fuse data",
    4 : "Inference",
    5 : "FME - transform",
    6 : "FME - something",
    7 : "FME - Load into ArcGIS"
}

TABLE_NAME = "test_table"

class Logger():

    def __init__(self, job_id: int=None, run_id:int=None, date_time:type(datetime.now())=datetime.now(), description:str=None):
        if job_id is None or description is None:
            raise MissingDataError("job_id or description not present:\njob_id : {}\ndescription : {}".format(job_id, description)) 
            # TODO move message to class


        self.job_id = job_id
        self.date_time = date_time
        self.description = description
        self.run_id = run_id

        if job_id not in job_name_lookup.keys():
            raise KeyError("Job ID invalid")
        else:
            self.job_name = job_name_lookup[job_id]

    
    def run(self, test_mode:bool=False, path_to_csv:str='./test_output.csv'):
        """
        Runs the logger - logging to the database when the user calls
        """
        self.test_mode = test_mode
        self.path_to_csv = path_to_csv

        if test_mode and not os.path.exists(str(self.path_to_csv)):
            # makes the empty csv file
            with open(self.path_to_csv, 'w'): pass


        # self.run_id = run_id # if parsed, set as that, if not we get from db/csv
        if self.run_id is not None:
            pass # do nothing
        else:
            if self.test_mode:
                self.run_id = self._get_run_id_from_csv()
            else:
                self.run_id = self._get_run_id_from_database()


        self._log_data(self._ingest_data())
        return self.run_id
    
    def _get_conn_str(self):
        """Gets the connection string for the SQL database
        FROM KEYVAULT AS OF NOW BUT MAY CHANGE
        """
        try:
            msi_auth = MsiAuthentication()
            ws = Workspace(subscription_id="7704663e-8944-4300-b951-6462d41ab638",
                    resource_group="arg-rt-pacedev-SpaceTech",
                    workspace_name="aml-WS-spacetech001",
                    auth=msi_auth
                )
            conn_str = ws.get_default_keyvault().get_secret('sql-conn-str')
        except Exception: # not sure what this will throw
            try:
                run = Run.get_context()
                conn_str = run.get_secret('sql-conn-str')
            except:
                raise KeyVaultConnectionError("Unable to obtain the connection string from Azure Key Vault")
        return conn_str


    def _get_run_id_from_database(self):
        """
        Obtains the run_id from the database by incrementing the maximum stored there. 
        """

        # TODO try/except
        # connect to database
        # get a connection string from keyvault
        try:
            conn_str = self._get_conn_str()
            cnxn = pyodbc.connect(conn_str)
            cursor = cnxn.cursor() 
        except Exception:
            raise DatabaseConnectionError("Unable to connect to Database")


        # find the max run_id
        sql = 'SELECT MAX(run_id) FROM ' + TABLE_NAME
        max_id = pd.read_sql(sql, cnxn).iloc[0, 0]

        if max_id is None: # for empty database
            max_id = 0

        # return increment
        return int(max_id) + 1


    def _ingest_data(self):
        """
        Ingests data from the function for writing to data base
        Returns: dictionary in preferred structure
        """

        self._dictionary = {
            "job_id" : self.job_id,
            "run_id" : self.run_id,
            "date_time" :self. date_time,
            "job_name" : self.job_name,
            "description" : self.description 
        }
        return self._dictionary




    def _log_data(self, data:dict): # dictionary
        # check that input is of desired format
        required_keys = ('job_id', 'run_id', 'date_time', 'job_name', 'description')
        if type(data) is dict and all (k in data for k in required_keys):
            # write the row
            if self.test_mode:
                self._write_row_csv(data.values())
            else:
                self._write_to_database(self._dictionary)
        else:
            raise TypeError("Input argument of unexpected type.")

        return self.run_id   

    def _write_to_database(self, dat):
        """
        Writes a line to the database from the data dictionary parsed. note this assumes the database and table aready exists
        """

        try:
            conn_str = self._get_conn_str()
            cnxn = pyodbc.connect(conn_str)
            cursor = cnxn.cursor()
        except Exception:
            raise DatabaseConnectionError("Unable to connect to Database")

        sql = '''
        INSERT INTO ''' + TABLE_NAME +  ''' (job_id, run_id, job_name, date_time, description)
        VALUES (?, ?, ?, ?, ?)
        '''

        try:
            cursor.execute(sql,  dat['job_id'], dat['run_id'], dat['job_name'], dat['date_time'], dat['description'])
            cursor.commit()
        except Exception as e:
            print(e)

    def _get_run_id_from_csv(self):
        """
        Gets the run_id from a csv file. Assumes csv exists as parent function (run) writes it 
        """
        try:
            df = pd.read_csv(self.path_to_csv)
        except FileNotFoundError as e:
            print(traceback.format_exc())
        # if file is empty (no headers)
        except EmptyDataError:
            return 1
        try:
            # returns an integer
            return np.max(df["run_id"].values) + 1
        # if file contains no data
        except ValueError:
            return 1 # because this means that there are no rows in file

    def _write_row_csv(self, line):
        """
        Method used for testing local ingestion of data before connection to database was established
        """
        with open(self.path_to_csv, 'a', newline='') as f:                
            writer = csv.writer(f)
            if os.stat(self.path_to_csv).st_size == 0:
                writer.writerow(self._dictionary.keys())
            writer.writerow(line)

    

# if __name__ == "__main__":
#     # testing functinality as I go, not a formal unit test
#     pass
    
